<?php
include("includes/db.php");
session_start();
if(!$_SESSION['u_id']){
  echo "<script>window.open('Login.php','_self')</script>";
}
elseif($_SESSION['type'] != '2'){
  echo "<script>window.open('Login.php','_self')</script>";
}else{
   $user_id = $_SESSION['u_id'];
}
$get_user = "select * from lean_users where u_id='$user_id'";
$run_user = mysqli_query($con,$get_user);
$row_user = mysqli_fetch_array($run_user);
$user_image= $row_user['picture'];
$user_name =$row_user['mail'];
$user_fname =$row_user['first_name'];
$user_sname =$row_user['surname'];
$user_add =$row_user['address'];
$user_city =$row_user['city'];
$user_state =$row_user['state'];
$user_postal =$row_user['postal_code'];
$user_tel =$row_user['telephone'];
$user_nm =$row_user['user_name'];
$user_pass =$row_user['password'];

if(isset($_POST['update'])){
  $update_id = $user_id;
  $u_fname = $_POST['name'];
  $u_sname = $_POST['surname'];
  $u_mail = $_POST['mail'];
  $u_phn = $_POST['phone'];
  $u_nm = $_POST['u_name'];
  $u_pass = $_POST['u_password'];
  $u_img = basename($_FILES['u_image']['name']);
  $u_img_tmp = $_FILES['u_image']['tmp_name'];
  $folder = "imagenes/";
  move_uploaded_file($u_img_tmp, $folder .$u_img);
  if(!empty($_FILES['u_image']['name'])) //new image uploaded
{
   //process your image and data
   $update_user = "update lean_users set mail='$u_mail',password='$u_pass',first_name='$u_fname',surname='$u_sname',user_name='$u_nm',telephone='$u_phn',picture='$u_img' where u_id='$update_id'";//save to DB with new image name
}
else // no image uploaded
{
   // save data, but no change the image column in MYSQL, so it will stay the same value
   $update_user = "update lean_users set mail='$u_mail',password='$u_pass',first_name='$u_fname',surname='$u_sname',user_name='$u_nm',telephone='$u_phn' where u_id='$update_id'";//save to DB but no change image column
}
  $run_user = mysqli_query($con, $update_user);
  if($run_user){
    // echo "<script>alert('Your account has been updated, please login again.')</script>";
    echo "<script>window.open('ProfileBusiness.php','_self')</script>";
  }
}
?>

<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="HomeBusiness.php" >Inicio</a>
        <a href="" id="active">Fundacion</a>

      </li>
    </ul>
  </nav>
</header>

<main>
  <div class= "container-image ">
    <img src="imagenes\bannercontacto.jpg"/>
    <div class="headCenter"><h1 style="margin: 0px;">PERFIL</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">INICIO</span> &nbsp; PERFIL</div>
  </div>
  <div class="info-container" style="margin-top: 100px;">
    <h3>Tu Información del Perfil</h3>
    <div class="prof"><i class="fa fa-book" style="font-size: 24px"> </i>  &nbsp; Nombres y Apellidos del Inscrito <br/><i class="fa fa-book" style="font-size: 24px"> </i>  &nbsp; Nombre de la Fundacion </br> <i class="fa fa-user" style="font-size: 24px"> </i>  &nbsp; Nombre del Usuario</div>
    <div class="prof" style="line-height: 2.5rem"><i class="fas fa-map-marker-alt"></i>  &nbsp; 198 West 21st street, <br/>Suite 721 New York NY 10016 <br/> <i class="fas fa-phone"></i> +1235 2355 98 </br> <i class="fa fa-paper-plane-o"></i> nombredecorreo@gmail.com </div>
    <div class="prof"><img src="imagenes\nologo.png" height='200px' width="50%"/> </div>
  </div>
  <div id="profileForm"  style=" position: relative; top:250px; height: 1100px">
    <h3>Estar en contacto</h3>
    <form name="message" action="" method="post" enctype="multipart/form-data">
    <div class="info-container" style="margin-left: 20px;">
    <div class="prof">
       <div class="form-group" style="margin-left:20px">
    <label for="formGroupExampleInput">Nombres</label>
    <input type="text" class="form-control" id="formGroupExampleInput" name="name" placeholder="Tu Nombre" value="<?php echo $user_fname;?>">
  </div>
  <div class="form-group" style="margin-left:20px">
    <label for="formGroupExampleInput2">Apellidos</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" name="surname" placeholder="Tu Apellidos " value="<?php echo $user_sname;?>">
  </div>
    <!-- <label  class="slabels"for="mail">Nombres </label>
    <input class="c-input-field " id="mail" type="email" value="" name="mail" placeholder="Tu Nombre"><label  class="slabels"for="mail">Apellidos</label>
    <input class="c-input-field " id="mail" type="email" value="" name="mail" placeholder="Tu Apellidos ">  --> </div>
    <div class="prof" style="line-height: 2.5rem"></div>
    <div class="prof"><img src="imagenes/<?=$user_image?>" height='200px' width="70%"/> <br/>
      <label for="file-upload" class="custom-file-upload" style="border: 1px solid #ccc;
    display: inline-block;
    padding: 6px 12px;
    cursor: pointer;
    border-radius: 3rem;
    color: white;
    background-color: #FFC300; 
    border: 0;  
    text-align: center; 
    width: 70%; 
    font-weight:bold;">  Seleccionar Foto
</label><input id="file-upload" type="file" style="display: none;" name="u_image" />
      <!-- <input type='file' class="signbutton" title="Select" id="aa" onchange="pressed()" style=" border-radius: 3rem;color:white; padding: 1rem ;background-color: #FFC300; border: 0;  text-align: center; width: 70%; font-weight:bold; color:transparent;" value="Seleccionar Foto">
      <button class="signbutton" id="upload" style="text-align: center; width: 70%; font-weight:bold">Seleccionar Foto</button></div> -->
  </div>
  <div class="form-group" style="margin:0px 20px 0px 20px; position: relative;top: 240px">
    <label for="exampleFormControlInput1">Correo</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Tu correo electrónico" value="<?php echo $user_name;?>" name="mail">
  </div>

   <div class="form-row" style="margin:0px 20px 0px 20px; position: relative;top: 300px">
    <div class="col-md-4 mb-3">
      <label for="validationCustom01">Telefono</label>
      <input type="phone" class="form-control" id="validationCustom01" name="phone" placeholder="Telefono" required value="<?php echo $user_tel;?>">
      <div class="valid-feedback">
        Looks good!
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom02">Usuario</label>
      <input type="text" class="form-control" id="validationCustom02" name="u_name" placeholder="Usuario"required value="<?php echo $user_nm;?>">
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom02">Contraseña</label>
      <input type="password" class="form-control" id="validationCustom02" name="u_password" placeholder="Contraseña" value="<?php echo $user_pass;?>" required>
    </div>
  </div>


  <!-- <div style="float:left;margin-right:40px; position: relative;top: 240px">
    <label  class="slabels"for="add">Correo</label>

    <input class="stretched " id="add" style="width: 1060px" type="text" value="" name="add" placeholder="Tu correo electrónico">
  </div>
 -->    <!-- <div class="info-container" style="background-color: red; position: relative;top: 200px">
    <div class="prof"><label  class="slabels"for="mail">Telefono</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="Telefono"> </div>
    <div class="prof"><label  class="slabels"for="mail">Usuario</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="Usuario"> </div>
    <div class="prof"><label  class="slabels"for="mail">Contraseña</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="Contraseña"> </div>
  </div> -->
   <div class="form-group" style="float:left;margin-right:40px; position: relative;top: 300px">
    <div class="form-check">
      <label  class="slabels signbutton"for="add" style="padding: 3px;">Nota:</label><br>
      <label class="form-check-label" for="invalidCheck" style="margin-left: 10px;">
        Solo puede Cambiar los datos (Telefono, Contraseña y Logo)
      </label>
    </div>
  </div>
  <!-- <div style="float:left;margin-right:40px; position: relative;top: 240px">
    <label  class="slabels signbutton"for="add" style="padding: 3px;">Nota:</label>
    <br/> <p style="padding-left: 10px">Solo puede Cambiar los datos (Telefono, Contraseña y Logo)</p>
  </div> -->
  <!-- <div class="row" style=" position: relative; top: 250px;">
    <div class="col text-center">
      <button class="btn btn-default signbutton" style="border-radius: 3rem;">Centered button</button>
    </div>
  </div> --> 
  <div style=" position: relative; top: 400px; text-align: center;"class="inner"><button class="signbutton" style="text-align: center;" name="update">Guardar Cambios
</button></div> 
  </form>
  </div>
  </main>

<footer>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>
</div>
</footer>
<script>
  window.pressed = function(){
    var a = document.getElementById('aa');
    if(a.value == "")
    {
        fileLabel.innerHTML = "Choose file";
    }
    else
    {
        var theSplit = a.value.split('\\');
        fileLabel.innerHTML = theSplit[theSplit.length-1];
    }
};
</script>
</body>

</html>