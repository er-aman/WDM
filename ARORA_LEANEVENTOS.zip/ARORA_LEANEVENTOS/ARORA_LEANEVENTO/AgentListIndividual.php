<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="HomeAgentLean.php">Inicio</a>
        <a href="" id="active">Lista de Voluntarios</a>
        <a href="AgentListBusiness.php">Lista de Fundaciones</a>
        <a href="AgentListEvents.php">Eventos</a>
        <a href="AgentProfile.php">Agente</a>

      </li>
    </ul>
  </nav>
</header>
<main>
  <h1 style="text-align: center;">Lista de Voluntarios</h1>
  <div id="page">
      <table id="cart">
        <thead id="headings">
          <tr>
            <th class="ipic">&nbsp</th>
            <th class="iname">NOMBRE DE VOLUNTARIO</th>
            <th class="icor">CORREO</th>
            <th class="itel">TELEFONO</th>
            <th class="ievent">EVENTO</th>
            <th class="iresp">RESPONSABLE</th>
          </tr>
        </thead>
        <tbody>
       
          <tr class="eventitm">
            <td><img src="imagenes\user.png" class="thumb"></td>
            <td style="text-align:left;">Nombre del Voluntario</td>
            <td>Direccion </td>
            <td>0000-000000</td>
            <td>Nombre del Evento</td>
            <td style="line-height: 1.3em">Nombre del Responsable</td>
          </tr>
           <tr class="eventitm">
            <td><img src="imagenes\user.png" class="thumb"></td>
            <td style="text-align:left;">Nombre del Voluntario</td>
            <td>Direccion </td>
            <td>0000-000000</td>
            <td>Nombre del Evento</td>
            <td style="line-height: 1.3em">Nombre del Responsable</td>
          </tr>
          <tr class="eventitm">
            <td><img src="imagenes\user.png" class="thumb"></td>
            <td style="text-align:left;">Nombre del Voluntario</td>
            <td>Direccion </td>
            <td>0000-000000</td>
            <td>Nombre del Evento</td>
            <td style="line-height: 1.3em">Nombre del Responsable</td>
          </tr>
          
        </tbody>
      </table>
    </div>
    <div id="pages">
      <div class="pn"><<</div>
      <div class="pn" style="background-color: #FFC300">1</div>
      <div class="pn">2</div>
      <div class="pn">3</div>
      <div class="pn">4</div>
      <div class="pn">>></div>
    </div>
</main>
<footer>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>

</div>
</footer>
</body>
</html>