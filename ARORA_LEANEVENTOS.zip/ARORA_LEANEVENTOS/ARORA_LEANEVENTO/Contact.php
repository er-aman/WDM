<?php
include("includes/db.php");
?>

<!DOCTYPE html>

<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
  <title>LEANEVENTO</title>
  
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="home.php" >Inicio</a>
        <a href="AboutUs.php" >Quienes Somos</a>
        <a href="http://amanarora.uta.cloud/blog/">Blog</a>
        <a href="signUp.php">Registrate</a>
        <a href="Contact.php" id="active">Contacto</a>
        <a href="Login.php">Iniciar Sesion</a>
        <a href="BuyFromUs.php">Comprar Boletos</a></li>

      </li>
    </ul>
  </nav>
</header>

<main>
  <div class= "container-image ">
    <img src="imagenes\bannercontacto.jpg"/>
    <div class="headCenter"><h1 style="margin: 0px;">CONTACTO</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">INICIO</span> &nbsp; CONTACTO</div>
  </div>
  <div id="info-container">
    <h3>Información del contacto</h3>
    <div class="info"><i class="fas fa-map-marker-alt"> </i>  &nbsp; 198 West 21st street, <br/>Suite 721 New York NY 10016</div>
    <div class="info"><i class="fas fa-phone"></i> +1235 2355 98</div>
    <div class="info"><i class="fa fa-paper-plane-o"></i> info@diazapps.com </div>
    <div class="info"><i class="fas fa-globe"></i> diazapps.com </div>
  </div>
  <div id="info-container">
    <h3>LEAN en las redes sociales</h3>
    <div class="info media"><img src="imagenes\facebook.png" height="40" width="40"/> <br/> <span style="color: #FFC300;">LEAN Ayuda Humanitaria</span></div>
    <div class="info media"><img src="imagenes\twitter.png" height="40" width="40"/><br/> <span style="color: #FFC300;">@LeanEmergente</span></div>
    <div class="info media"><img src="imagenes\instagram.png" height="40" width="40"/><br/> <span style="color: #FFC300;">@LeanAyudaHumanitaria</span></div>
    <div class="info media"><img src="imagenes\correo.png" height="40" width="40"/><br/> <span style="color: #FFC300;">lean emergente@gmail.com</span></div>
  </div>
  <div id="contactForm">
    <h3>Estar en contacto</h3>
    <form name="message" action="Contact.php" method="post">
       <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4" style="padding-left: 20px; ">Nombre</label>
      <input type="text" class="form-control" id="inputEmail4" name="name" placeholder="Tu Nombre" required style="margin-left: 20px;max-width:84%">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4" style="padding-left: 20px;">Apellido</label>
      <input type="text" class="form-control" id="inputPassword4" name="surname" placeholder="Tu Apellido" required style=" margin-left: 20px; max-width:84%">
    </div>
  </div>
   <div class="form-group">
    <label for="inputAddress" style="padding-left: 20px; ">Correo</label>
    <input type="text" class="form-control" id="inputAddress" type="email" value="" name="email" placeholder="Tu correo electrónico
" required placeholder="1234 Main St" style=" margin-left: 20px; max-width:92%">
  </div>
  <div class="form-group">
    <label for="inputAddress" style="padding-left: 20px; ">Tema</label>
    <input type="text" class="form-control" id="inputAddress" type="text" value="" name="topic" placeholder="
Su asunto de este mensaje." required placeholder="1234 Main St" style=" margin-left: 20px; max-width:92%">
  </div>
   <div class="form-group">
    <label for="exampleFormControlTextarea1" style="padding-left: 20px;">Mensaje</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="6" type="text" name="message" placeholder="Di algo sobre nosotros" required style=" margin-left: 20px; max-width:92%"></textarea>
  </div>
  <div style=" position: relative; left: 50%;"class="inner"><button class="signbutton" style="text-align: center;" type="submit" name="submit">Enviar mensaje
</button></div>
  </form>
<?php
   $f_name=$l_name=$email=$topic=$message="";
if(isset($_POST['submit'])){
  //Lean Evento recieves the message through this code
  if(isset($_POST['name'])){
    $f_name.= $_POST['name'];
  }
  if(isset($_POST['surname'])){
    $l_name.= $_POST['surname'];
  }
  if(isset($_POST['email'])){
    $email.= $_POST['email'];
  }
  if(isset($_POST['topic'])){
    $topic.= $_POST['topic'];
  }
  if(isset($_POST['message'])){
    $message.= $_POST['message'];
  }
  $reciever_email="aman.cqu@gmail.com";

  mail($reciever_email,$topic,$message,$email);

  // Send email to the sender
  if(isset($_POST['email'])){
    $email = $_POST['email'];
  }

  $subject= "Welcome to LEANEVENTOS";

  $msg ="We Will get back to you soon, thanks for sending the message";

  $from = "aman.cqu@gmail.com";

  mail($email,$subject,$msg,$from);

  echo "<h2 align='center'> Your message has been sent successfully.</h2>";
}
?>

  </div>
  </main>

<footer>
    <div class="social">
        <div id="fheading"><h4 font-weight:bold"><span>LEAN EN LAS REDES SOCIALES</span></h4></div>
        <div class="icons">
      <div class="icons">
      <a href="#"> 
<i class="fa fa-twitter" style="font-size:24px;color:#FFC300"></i> </a>
 <a href="#"> <i class="fa fa-facebook"  style="font-size:24px;color:#FFC300"></i></a> 
 <a href="#"> <i class="fa fa-instagram"style="font-size:24px;color:#FFC300"></i></a> 
    </div>
    </div>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>
</div>
</footer>
</body>

</html>