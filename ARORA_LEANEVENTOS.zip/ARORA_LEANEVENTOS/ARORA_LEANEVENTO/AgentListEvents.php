<?php
include("includes/db.php");
session_start();
if(isset($_GET['delete_event'])){
  include("delete_event.php");
}
?>

<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="HomeAgentLean.php">Inicio</a>
        <a href="AgentListIndividual.php">Lista de Voluntarios</a>
        <a href="AgentListBusiness.php">Lista de Fundaciones</a>
        <a href="" id="active">Eventos</a>
        <a href="AgentProfile.php">Agente</a>


      </li>
    </ul>
  </nav>
</header>
<main>
  <h1 style="text-align: center;">Lista de Eventos</h1>
  <div id="agregar">
    <div class="inner" style="margin-right: 30px; float:right;"><button id="addEvent" class="signbutton" style="background-color: #32CD32;">Agregar</button></div>
  </div>
  <div id="page">
      <table id="cart">
        <thead id="headings">
          <tr>
            <th class="photo">&nbsp</th>
            <th class="event">DETALLES DEL EVENTOS</th>
            <th class="lugar">LUGAR</th>
            <th class="fecha">FECHA</th>
            <th class="hora">MODIFICIAR</th>
            <th class="asist">ELIMINAR</th>
          </tr>
        </thead>
        <tbody>
             <?php
          $get_events = "select * from event where agent_id='$user_id'";
          $run_query = mysqli_query($con, $get_events);
          while ($row_events = mysqli_fetch_array($run_query)) {
            $event_id = $row_events['event_id'];
            $event_name = $row_events['event_name'];
            $event_resp = $row_events['responsible'];
            $event_date = $row_events['date'];
            $event_time = $row_events['time'];
            $event_desc = $row_events['description'];
            $event_img = $row_events['image'];
            echo "
             <tr class='eventitm'>
            <td><img src='imagenes/$event_img' class='thumb'></td>
            <td style='text-align:left;'>$event_name</td>
            <td>$event_desc</td>
            <td>$event_date</td>
            <td><i class='fa fa-edit conbutton' style='font-size: 24px'></i></td>
            <td><i class='fa fa-trash conbutton' style='font-size: 24px; background-color:#B22222'></i></td>

          </tr>
            ";
          }

          ?>
          
        </tbody>
      </table>
    </div>
<div id="pages">
      <div class="pn"><<</div>
      <div class="pn" style="background-color: #FFC300">1</div>
      <div class="pn">2</div>
      <div class="pn">3</div>
      <div class="pn">4</div>
      <div class="pn">>></div>
    </div>
</main>
<footer>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>

</div>
</footer>
<script type="text/javascript">
    document.getElementById("addEvent").onclick = function () {
        location.href = "agregar.php";
    };
</script>
</body>
</html>