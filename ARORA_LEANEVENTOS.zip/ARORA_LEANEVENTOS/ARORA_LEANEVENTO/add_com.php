<?php
include("includes/db.php");
if(!$_SESSION['u_id']){
  echo "<script>window.open('Login.php','_self')</script>";
}
elseif($_SESSION['type'] != '3'){
  echo "<script>window.open('Login.php','_self')</script>";
}else{
   $user_id = $_SESSION['u_id'];


?>
<?php
// $get_user = "select * from lean_users where u_id='$user_id'";
// $run_user = mysqli_query($con,$get_user);
// $row_user = mysqli_fetch_array($run_user);
// $user_image= $row_user['picture'];
// $user_name =$row_user['mail'];
// $user_fname =$row_user['first_name'];
// $user_sname =$row_user['surname'];
// $user_add =$row_user['address'];
// $user_city =$row_user['city'];
// $user_state =$row_user['state'];
// $user_postal =$row_user['postal_code'];
// $user_tel =$row_user['telephone'];

if(isset($_GET['add_com'])){
	$add_id = $_GET['add_com'];
	$com = $_SESSION['com'];
	$ad_evt="update found_sub  set comm='$com' from found_sub where user_id='$add_id'";
	$run_ev = mysqli_query($con,$ad_evt);
	if($run_ev){
		echo "<script>alert('Comission has been set')</script>";
		echo "<script>window.open('AgentListBusiness.php','_self')</script>";
	}
}

?>
<?php }?>