<?php
include("includes/db.php");
if(!$_SESSION['u_id']){
  echo "<script>window.open('Login.php','_self')</script>";
}
elseif($_SESSION['type'] != '2'){
  echo "<script>window.open('Login.php','_self')</script>";
}else{
   $user_id = $_SESSION['u_id'];

?>
<?php

if(isset($_GET['del_bEvent'])){
	$delete_id = $_GET['del_bEvent'];
	$del_evt= "delete from found_sub where sub_id='$delete_id'";
	$run_del = mysqli_query($con,$del_evt);
	if($run_del){
		echo "<script>alert('Event has been deleted')</script>";
		echo "<script>window.open('myBEvents.php','_self')</script>";
	}
}

?>
<?php }?>