<?php
include("includes/db.php");
session_start();
if(isset($_GET['add_com'])){
  include("add_com.php");
}
if(!$_SESSION['u_id']){
  echo "<script>window.open('Login.php','_self')</script>";
}
elseif($_SESSION['type'] != '3'){
  echo "<script>window.open('Login.php','_self')</script>";
}else{
   $user_id = $_SESSION['u_id'];
}
?>

<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="HomeAgentLean.php">Inicio</a>
        <a href="AgentListIndividual.php">Lista de Voluntarios</a>
        <a href="" id="active">Lista de Fundaciones</a>
        <a href="AgentListEvents.php">Eventos</a>
        <a href="AgentProfile.php">Agente</a>

      </li>
    </ul>
  </nav>
</header>
<main>
  <h1 style="text-align: center;">Lista de Fundaciones</h1>
  <div id="page">
      <table id="cart">
        <thead id="headings">
          <tr>
            <th class="bpic">&nbsp</th>
            <th class="bname">NOMBRE DE VOLUNTARIO</th>
            <th class="bcor">EVENTO</th>
            <th class="btel">RESPONSABLE</th>
            <th class="bevent">COMISION</th>
            <th class="bresp">CONFIRMAR</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $get_events = "select * from found_sub order by 1 DESC";
          $run_query = mysqli_query($con, $get_events);
          while ($row_events = mysqli_fetch_array($run_query)) {
            $event_id = $row_events['event_id'];
            $u_id = $row_events['user_id'];
            $event_name = $row_events['resp'];
            $event_resp = $row_events['event_name'];
            $get_users = "select * from lean_users where u_id='$u_id'";
            $run_get = mysqli_query($con, $get_users);
            while ($row_user = mysqli_fetch_array($run_get)) {
              $u_name = $row_user['first_name'];
              $u_img = $row_user['picture'];
            echo "
             <tr class='eventitm'>
            <td><img src='imagenes/$u_img' class='thumb'></td>
            <td style='text-align:left;'>$u_name</td>
            <td>$event_resp</td>
            <td>$event_name</td>
            <form action='' method='post'>
            <td><input type='text' name='TextBox' id='TextBox' form='message' class='pn' style='transform: translateX(100%);' value='1' /></td>
            </form>
            <td><a href='AgentListBusiness.php?add_com=$u_id'><button class='conbutton'>Asignar</button></a></td>
          </tr>
            ";
          }
        }

          ?>
       <!-- 
          <tr class="eventitm">
            <td><img src="imagenes\nologo.png" class="thumb"></td>
            <td style="text-align:left;">Nombre del Fundacion</td>
            <td>Nombre del Evento </td>
            <td style="line-height: 1.3em">Nombre del Responsable</td>
            <td><input type="text" name="TextBox" id="TextBox" form="message" class="pn" style="transform: translateX(100%);" value="1" /></td>
            <td><button class="conbutton" >Asignar</button></td>
          </tr>
           <tr class="eventitm">
            <td><img src="imagenes\nologo.png" class="thumb"></td>
            <td style="text-align:left;">Nombre del Fundacion</td>
            <td>Nombre del Evento </td>
            <td style="line-height: 1.3em">Nombre del Responsable</td>
            <td><div class="pn" style="transform: translateX(100%);">2</div></td>
            <td><button class="conbutton" >Asignar</button></td>
          </tr>
          <tr class="eventitm">
            <td><img src="imagenes\nologo.png" class="thumb"></td>
            <td style="text-align:left;">Nombre del Fundacion</td>
            <td>Nombre del Evento </td>
            <td style="line-height: 1.3em">Nombre del Responsable</td>
            <td><div class="pn" style="transform: translateX(100%);">2</div></td>
            <td><button class="conbutton" >Asignar</button></td>
          </tr> -->
          
        </tbody>
      </table>
    </div>
    <div id="pages">
      <div class="pn"><<</div>
      <div class="pn" style="background-color: #FFC300">1</div>
      <div class="pn">2</div>
      <div class="pn">3</div>
      <div class="pn">4</div>
      <div class="pn">>></div>
    </div>
</main>
<footer>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>

</div>
</footer>
</body>
</html>