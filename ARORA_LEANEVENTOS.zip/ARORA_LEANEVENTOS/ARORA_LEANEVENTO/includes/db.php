<?php 
$con = mysqli_connect("localhost","root","amank","lean");
?>