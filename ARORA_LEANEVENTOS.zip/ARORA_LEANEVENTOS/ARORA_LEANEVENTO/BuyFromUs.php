<?php
include("includes/db.php");
?>

<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="home.php" >Inicio</a>
        <a href="AboutUs.php" >Quienes Somos</a>
        <a href="http://amanarora.uta.cloud/blog/">Blog</a>
        <a href="signUp.php">Registrate</a>
        <a href="Contact.php">Contacto</a>
        <a href="Login.php">Iniciar Sesion</a>
        <a href="BuyFromUs.php" id="active">Comprar Boletos</a></li>

      </li>
    </ul>
  </nav>
</header>

<main>
  <div class= "container-image ">
    <img src="imagenes\bannercboleto.jpg"/>
    <div class="headCenter"><h1 style="margin: 0px;">COMPRAR BOLETOS</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">INICIO</span> &nbsp; COMPRAR BOLETOS</div>
  </div>
  <div id="events">
     <h2>NUESTROS EVENTOS</h2>
     <p> Tu asistencia es importante para nosotros visitanos en los eventos qu estamos realizando.</p>
  </div>
  <div id="content" class="container"><!-- container Starts -->

<div class="row" style="position: relative;top: 156px;"><!-- row Starts -->

    <?php
    $get_events = "select * from event order by 1 DESC"; 
    $run_events = mysqli_query($con,$get_events);
    while ($row_events = mysqli_fetch_array($run_events)) {
      $event_id =$row_events['event_id'];
      $event_nm =$row_events['event_name'];
      $event_price = $row_events['ticket_value'];
      $event_imaeg = $row_events['image'];
      echo "
      <div class='col-xs-6 col-sm-3'>

<div class='product' >

<a href='DetailPage.php?event_id=$event_id' >

<img src='imagenes/$event_imaeg' class='img-responsive' >

</a>

<div class='text' >

<h3><a href='DetailPage.php?event_id=$event_id' >$event_nm</a></h3>

<p class='price' style='color:#FFC300'>$$event_price</p>

</div>


</div>

</div>
      ";
    }
    ?>

</div><!-- row Ends -->

</div><!-- container Ends -->
  </div>  
  </main>

<footer>
 <div class="subscribe subscribe_theme">
      <form class="subscribe__item form" id="form" action="https://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('https://feedburner.google.com/fb/a/mailverify?uri=Leanevento', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">
        <div class='register-text'><i class="fa fa-paper-plane-o"></i>    Registrese para recibir un <br/> bolitin </div>
        <input class="form__email" id="email" style=" border-bottom-left-radius: 2rem; border-top-left-radius: 2rem; border: .0001rem solid #FFC300; flex-grow: 1; max-width: 20rem; height: 3.5rem; "  name="email" type="email" name="email" placeholder="Introduce tu correo electronico" >
        <input type="hidden" value="Leanevento" name="uri"/><input type="hidden" name="loc" value="en_US"/>
        <input class="form__submit button button_theme_dark" id="submit" type="submit" style="height: 3.5rem" value="Suscribir">
      </form>
    </div>
    <div class="social">
        <div id="fheading"><h4 font-weight:bold"><span>LEAN EN LAS REDES SOCIALES</span></h4></div>
        <div class="icons">
      <a href="#"> 
<i class="fa fa-twitter" style="font-size:24px;color:#FFC300"></i> </a>
 <a href="#"> <i class="fa fa-facebook"  style="font-size:24px;color:#FFC300"></i></a> 
 <a href="#"> <i class="fa fa-instagram"style="font-size:24px;color:#FFC300"></i></a> 
    </div>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>

</div>
</footer>
</body>

</html>