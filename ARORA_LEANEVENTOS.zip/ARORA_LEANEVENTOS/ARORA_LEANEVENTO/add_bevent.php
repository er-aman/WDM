<?php
include("includes/db.php");
if(!$_SESSION['u_id']){
  echo "<script>window.open('Login.php','_self')</script>";
}
elseif($_SESSION['type'] != '2'){
  echo "<script>window.open('Login.php','_self')</script>";
}else{
   $user_id = $_SESSION['u_id'];

?>
<?php
// $get_user = "select * from lean_users where u_id='$user_id'";
// $run_user = mysqli_query($con,$get_user);
// $row_user = mysqli_fetch_array($run_user);
// $user_image= $row_user['picture'];
// $user_name =$row_user['mail'];
// $user_fname =$row_user['first_name'];
// $user_sname =$row_user['surname'];
// $user_add =$row_user['address'];
// $user_city =$row_user['city'];
// $user_state =$row_user['state'];
// $user_postal =$row_user['postal_code'];
// $user_tel =$row_user['telephone'];

if(isset($_GET['add_bevent'])){
	$add_id = $_GET['add_bevent'];
	$check_evt= "select * from found_sub where event_id='$add_id'";
	$check_res = mysqli_query($con,$check_evt);
	$row_check= mysqli_fetch_array($check_res);
	if($row_check!=0){
		echo "<script>alert('Event has already been subscribed')</script>";
		echo "<script> myfunction();</script>";
		echo "<script>window.open('HomeBusiness.php','_self')</script>";
	}else{
	$get_event = "select * from event where event_id='$add_id'";
	$run_get = mysqli_query($con,$get_event);
	$row_get= mysqli_fetch_array($run_get);
	$ev_name= $row_get['event_name'];
	$ev_res= $row_get['responsible'];
	$ev_date= $row_get['date'];
	$ev_time= $row_get['time'];
	$ev_desc= $row_get['description'];
	$ev_img= $row_get['image'];
	$ev_val= $row_get['ticket_value'];
	$ad_evt= "insert into found_sub(event_name,place,resp,date,time,image,event_id,user_id,comm) values ('$ev_name','$ev_desc','$ev_res','$ev_date','$ev_time','$ev_img','$add_id','$user_id','0')";
	$run_ev = mysqli_query($con,$ad_evt);
	if($run_ev){
		echo "<script>alert('Event has been subscribed')</script>";
		echo "<script>window.open('HomeBusiness.php','_self')</script>";
		echo "<script>'document.getElementById(\"welcome\").style.display= \"block\"'</script>";
	}
}
}

?>
<?php }?>