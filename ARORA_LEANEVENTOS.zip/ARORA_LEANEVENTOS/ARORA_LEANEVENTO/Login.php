<?php
session_start();
include("includes/db.php");
?>
<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="home.php" >Inicio</a>
        <a href="AboutUs.php" >Quienes Somos</a>
        <a href="http://amanarora.uta.cloud/blog/">Blog</a>
        <a href="signUp.php">Registrate</a>
        <a href="Contact.php">Contacto</a>
        <a href="Login.php" id="active">Iniciar Sesion</a>
        <a href="BuyFromUs.php">Comprar Boletos</a></li>

      </li>
    </ul>
  </nav>
</header>

<main>
  <div class= "container-image ">
    <img src="imagenes\bannerlogin.jpg"/>
    <div class="headCenter"><h1 style="margin: 0px;">INICIAR SESIÓN</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">INICIO</span> &nbsp; INICIAR SESIÓN</div>
  </div>
<div id="form-outer">
  <form name="login" method="post">
    <p style="padding:10px;">Iniciar sesión</p>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Nombre de Usuario</label>
      <input class="form-control" id="inputEmail4" type="email" name="u_mail" placeholder="Nombre de Usuario" required>
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Contraseña</label>
      <input type="password" class="form-control" id="inputPassword4" placeholder="Contraseña" name="u_password" required>
    </div>
  </div>
  <section>
    <div id="forgot">
      <a href="#indi"><button id="forgotbtn" onclick= "document.getElementById('indi').style.display='block'">olvidó su contraseña?</button></a>
      </div>
      <div id="login">
      <input id="submitBtn" type="submit" value="Entra" style="margin-top: 10px;" name="Login">
      </div>                                                                                       
    </section>
 <!--  <div class="form-row text-center">
    <div class="col-12">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
 </div> -->
</form>
<!-- <form name="login" action="Login.php" method="post">
    <section>
      <p style="padding:10px;">Iniciar sesión</p>
  <div style="float:left;margin-right:20px;">
    <label  class="labels"for="name">Nombre de Usuario</label>
    <input class="input-field " id="name" type="text" name="u_name" required>
  </div>

  <div style="float:left;">
    <label class="labels" for="password">Contraseña</label>
    <input class="input-field " id="pass" type="password" name="u_password" required>
  </div>
    </section>

    <section>
    <div id="forgot">
      <a href="#indi"><button id="forgotbtn" onclick= "document.getElementById('indi').style.display='block'">olvidó su contraseña?</button></a>
      </div>
      <div id="login">
      <input id="submitBtn" type="submit" value="Entra" name="Login">
      </div>                                                                                       
    </section>
</form>
</div> -->
<div id="indi" class="bg">
<form name="message" class="forgotpwd animate">
    <section>
      <p style="padding:5px; margin-top:0;">Recupera tu contraseña</p>
      <hr>
      <form>
  <div class="form-group">
    <label for="formGroupExampleInput">Correo</label>
    <input type="email" class="form-control" id="formGroupExampleInput" value="" name="email" placeholder="Correo">
  </div>
      <hr style="margin-top: 50px">
       <div style="margin: 10px 0px 10px 20px;float:right"class="inner"><button style="background-color:#C0C0C0; color:black; padding:1rem"class="signbutton">Cerrar</button> <button class="signbutton">Enviar</button></div>
    </section>
</form>
</div>
</main>
<footer>
    <div class="social">
        <div id="fheading"><h4 font-weight:bold"><span>LEAN EN LAS REDES SOCIALES</span></h4></div>
        <div class="icons">
      <a href="#"> 
<i class="fa fa-twitter" style="font-size:24px;color:#FFC300"></i> </a>
 <a href="#"> <i class="fa fa-facebook"  style="font-size:24px;color:#FFC300"></i></a> 
 <a href="#"> <i class="fa fa-instagram"style="font-size:24px;color:#FFC300"></i></a> 
    </div>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>

</div>
</footer>
</body>
<script>
document.getElementById("forgotbtn").addEventListener("click", function(event){
  event.preventDefault()
});
var i = document.getElementById('indi');
window.onclick = function(event) {
   if (event.target == i) {
       i.style.display = "none";
   }}
</script>
</html>

<?php
if(isset($_POST['Login'])){
  $user_mail = $user_pass = '';
  if(isset($_POST['u_mail'])){
    $user_mail .= $_POST['u_mail'];
  }
  if(isset($_POST['u_password'])){
    $user_pass .= $_POST['u_password'];
  }
  $select_user = "select * from lean_users where mail='$user_mail' AND password='$user_pass'";
  $run_user = mysqli_query($con, $select_user);
  $row = mysqli_fetch_array($run_user);
  $type = $row['role_id'];

    $check_user = mysqli_num_rows($run_user);
    if($check_user==0){
        echo "<script> alert('password or email is wrong.')</script>";
        exit();
    }
    if($check_user==1){
        $_SESSION['user_mail'] = $row['mail'];
        $_SESSION['type'] = $row['role_id'];
        $_SESSION['u_id'] = $row['u_id'];

        if($type == '1'){
          echo"<script>alert('You are Logged In')</script>";
        echo "<script>window.open('HomeIndividual.php','_self')</script>";

        }elseif ($type =='2') {
         echo"<script>alert('You are Logged In')</script>";
        echo "<script>window.open('HomeBusiness.php','_self')</script>"; 
        }elseif ($type =='3') {
         echo"<script>alert('You are Logged In')</script>";
        echo "<script>window.open('HomeAgentLean.php','_self')</script>"; 
        }
    }
}

?>
