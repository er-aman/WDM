<?php
session_start();
if(!$_SESSION['u_id']){
  echo "<script>window.open('Login.php','_self')</script>";
}
elseif($_SESSION['type'] != '3'){
  echo "<script>window.open('Login.php','_self')</script>";
}else{
   $user_id = $_SESSION['u_id'];
}
?>

<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="HomeAgentLean.php" id="active">Inicio</a>
        <a href="AgentListIndividual.php">Lista de Voluntarios</a>
        <a href="AgentListBusiness.php">Lista de Fundaciones</a>
        <a href="AgentListEvents.php">Eventos</a>
        <a href="AgentProfile.php">Agente</a>
         <?php 
        if(!isset($_SESSION['u_id'])){
          echo "";
        }else{
          echo "<a href='Logout.php'>Logout</a>";
        }
        ?>

      </li>
    </ul>
  </nav>
</header>
<main>
  <div class= "container-image ">
    <img src="imagenes\bannerlean1.jpg"/>
    <img src="imagenes\logo-blanco.png" style="width: 200px;height: 200px; align-content: left;position: absolute;
  top: 50px;
  left: 60%;" />
  </div> 
</main>
<footer>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>

</div>
</footer>
</body>
</html>