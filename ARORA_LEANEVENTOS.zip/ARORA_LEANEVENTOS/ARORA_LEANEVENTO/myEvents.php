<?php
include("includes/db.php");
session_start();
if(isset($_GET['del_indEvent'])){
  include("del_indEvent.php");
}
if(!$_SESSION['u_id']){
  echo "<script>window.open('Login.php','_self')</script>";
}
elseif($_SESSION['type'] != '1'){
  echo "<script>window.open('Login.php','_self')</script>";
}else{
   $user_name = $_SESSION['u_id'];
}
?>

<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="HomeIndividual.php" >Inicio</a>
        <a href="" id="active" >My Events</a>
        <!-- ?= $user_name;?> -->
        <a href="IndividualProfile.php">Individual</a>
        <?php 
        if(!isset($_SESSION['u_id'])){
          echo "";
        }else{
          echo "<a href='Logout.php'>Logout</a>";
        }
        ?>

      </li>
    </ul>
  </nav>
</header>
<main>
  <h1 style="text-align: center;">Lista de Eventos</h1>
  <div id="page">
      <table id="cart">
        <thead id="headings">
          <tr>
            <th class="photo">&nbsp</th>
            <th class="event">DETALLES DEL EVENTOS</th>
            <th class="lugar">LUGAR</th>
            <th class="fecha">FECHA</th>
            <th class="hora">HORA</th>
            <th class="asist">ASISTENCIA</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $get_events = "select * from individual_sub order by 1 DESC";
          $run_query = mysqli_query($con, $get_events);
          while ($row_events = mysqli_fetch_array($run_query)) {
            $event_id = $row_events['sub_id'];
            $event_name = $row_events['event_name'];
            $event_resp = $row_events['place'];
            $event_date = $row_events['date'];
            $event_time = $row_events['time'];
            $event_img = $row_events['image'];
            echo "
             <tr class='eventitm'>
            <td><img src='imagenes/$event_img' class='thumb'></td>
            <td style='text-align:left;'>$event_name</td>
            <td>$event_resp</td>
            <td>$event_date</td>
            <td>$event_time</td>
            <td><a href='myEvents.php?del_indEvent=$event_id'><button class='conbutton'>Delete</button></a></td>
          </tr>
            ";
          }

          ?>
        </tbody>
      </table>
    </div>
    <div id="welcome" class="bg">
<form name="message" class="forgotpwd animate">
    <section>
      <h3 style="text-decoration: none; text-align: center;">Bienvenido</h3>
      <hr>
      <p style="text-align: center; font-size: 1.2rem">Gracias por ser un Voluntario en nuestros evento.</p>
      <hr style="margin-top: 50px">
       <div style="margin: 30px 0px 10px 2px;float:right"class="inner"><button style="background-color:#C0C0C0; color:black; padding:10px 20px 10px 20px"class="signbutton">Close</button> </div>
    </section>
</form>
</div>
</main>
<footer>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>

</div>
</footer>
<script type="text/javascript">
  function myfunction(){
    document.getElementById("welcome").style.display= "block";
  }
</script>
</body>
</html>
