<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>LEANEVENTO</title>
	<link href="CSS\leanevent.css" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet" />
	<link crossorigin="anonymous" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" rel="stylesheet" />
	<link href="imagenes/favicon.ico" rel="icon" type="image/x-icon" />
	<link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
</head>
<body>
<div id="wrapper">
<header id="header">
<nav id="nav-bar"><img alt="Lean logo" class="hidden-xs" src="imagenes\logo-blanco.png" />
<div id="logoName">
<h3>LEANEVENTO</h3>
</div>

<ul>
	<li><a href="home.php">Inicio</a> <a href="AboutUs.php" id="active">Quienes Somos</a> <a href="http://amanarora.uta.cloud/blog/">Blog</a> <a href="signUp.php">Registrate</a> <a href="Contact.php">Contacto</a> <a href="Login.php">Iniciar Sesion</a> <a href="BuyFromUs.php">Comprar Boletos</a></li>
</ul>
</nav>
</header>

<main>
<div class="container-image "><img src="imagenes\bannerabout.jpg" />
<div class="headCenter">
<h1 style="margin: 0px;">QUIENES SOMOS</h1>
</div>

<div class="optionsCent"><span style="color: #FFC300">INICIO</span> &nbsp; QUIENES SOMOS</div>
</div>

<div id="about-container">
<div class="aboutContent">
<p><b>&iquest;Qu&eacute; es LEAN?</b></p>

<p id="aboutData">LEAN es una asociaci&oacute;n civil sin fines de lucro conformada por gente con gran sensibilidad social, dedicada a la defensa de los derechos humanos y la consecuci&oacute;n de ayuda humanitaria, favoreciendo directamente o a trav&eacute;s de otras asociaciones o agrupaciones provinciales a venezolanos residentes en Espa&ntilde;a y a quienes viven en Venezuela.</p>

<p><b>&iquest;Cu&aacute;les son los fines de LEAN?</b></p>

<p id="aboutData">LEAN est&aacute; dedicada a fomentar valores e instaurarlos como principios, trabajar en formaci&oacute;n c&iacute;vica, promover y defender las libertades individuales y los derechos humanos en Venezuela, sensibilizar a la gente sobre la importancia de conocer, respetar y practicar los principios contenidos en la Declaraci&oacute;n Universal de Derechos Humanos, asistir a v&iacute;ctimas de actos violentos y persecuci&oacute;n, favorecer la adquisici&oacute;n de conocimiento a trav&eacute;s de la lectura y trabajar incansablemente en la ayuda humanitaria como gesto de solidaridad y buena voluntad.</p>

<p><b>&iquest;Cu&aacute;les son las actividades de LEAN?</b></p>

<p id="aboutData">LEAN trabaja en el desarrollo y publicaci&oacute;n de estudios de investigaci&oacute;n sobre temas de inter&eacute;s social, cultural, pol&iacute;tico y econ&oacute;mico, preparaci&oacute;n de ponencias para foros y conferencias, presentaci&oacute;n en eventos especializados y mesas de trabajo, petici&oacute;n de colaboraci&oacute;n a personalidades de reconocida trayectoria, estudio de casos de violaci&oacute;n de derechos humanos a trav&eacute;s de letrados voluntarios, asistencia y representaci&oacute;n para la defensa de las v&iacute;ctimas de actos violentos y persecuci&oacute;n, lanzamiento de campa&ntilde;as sobre valores c&iacute;vicos y derechos humanos, planificaci&oacute;n y ejecuci&oacute;n de programas de voluntariado para brindar ayuda humanitaria y organizaci&oacute;n de charlas sobre la situaci&oacute;n econ&oacute;mica, pol&iacute;tica y social de Venezuela y dem&aacute;s temas de inter&eacute;s mundial.</p>

<p><b>&iquest;Qu hacemos?</b></p>

<p id="aboutData">La asociaci&oacute;n civil LEAN fue creada con el objetivo de ayudar, a trav&eacute;s de acciones concretas, a nuestros conciudadanos en Venezuela ante la grave escasez de medicinas e insumos m&eacute;dicos en que se encuentra el pa&iacute;s. Nuestra misi&oacute;n consiste en recolectar ayuda m&eacute;dico sanitaria en delegaciones en Espa&ntilde;a y, a trav&eacute;s de agentes de transporte, llevarlos a Venezuela para que otras asociaciones se encarguen de su distribuci&oacute;n. De esta manera aportamos nuestro granito de arena ayudando a llevar asistencia humanitaria a Venezuela. Somos una asociaci&oacute;n sin fines de lucro, dedicada a la defensa de los Derechos Humanos.</p>
</div>

<div class="aboutContent">
<p><b>&iquest;CÓMO PUEDES AYUDAR?</b></p>

<p><b>PUEDES AYUDAR DE TRES FORMAS:</b></p>

<ul>
	<li>Dona material médico e insumos para Venezuela.</li>
	<li>A través de donaciones económicas</li>
	<li>Hazte voluntario.</li>
</ul>

<p><b>&iquest;DÓNDE ESTAMOS?</b></p>

<p><b>SOMOS 17 COORDINACIONES EN ESPAÑA:</b></p>

<p>Alicante - Almería - Cataluña - Granada - Islas Canarias - Islas Baleares - León - Madrid -Málaga - Salamanca - Sevilla - Valencia - Valladolid - Zaragoza - LEAN EEUU.</p>

<p><b>INSTITUCIONES Y ORGANIZACIONES BENEFICIADAS EN VENEZUELA:</b></p>

<p>Ayudamos a 11 Estados a través de 35 puntos de destino:</p>

<div id="rightaboutdiv">
<div class="listabout">
<ul>
	<li>LEAN Anzoátegui</li>
	<li>Funsaluz Barcelona, Valencia y Maracaibo</li>
	<li>Fundación La Pastillita</li>
	<li>LEAN Aragua 1</li>
	<li>Parroquia Michelena</li>
	<li>LEANCaracas1,2,3,4,5,6,7,8y9.</li>
	<li>Seno Salud</li>
	<li>Somos Ayuda</li>
	<li>FDIV</li>
	<li>Parroq. San Fco. de Asis</li>
	<li>ONG Pan y Vino</li>
	<li>LEAN Nueva Esparta</li>
	<li>Parroquia San Félix</li>
	<li>Fundación Esperanza de Vida</li>
	<li>Caritas de Venezuela</li>
</ul>
</div>

<div class="listabout">
<ul>
	<li>Fund. Denzel El Guerrero</li>
	<li>Mensajeras de la Alegría</li>
	<li>Caritas Valle de la Pascua</li>
	<li>Caritas Diocesana Barquisimeto</li>
	<li>Hogar de Niños Impedidos Don Orione</li>
	<li>AVEPEII</li>
	<li>Casa Hogar Madre Teresa de Calcuta</li>
	<li>Seminario Santa Rosa de Lima</li>
	<li>Casa Arag&oacute;n</li>
	<li>Caritas Parraquial de M&eacute;rida</li>
	<li>Asociaci&oacute;n Dr. Pa&uacute;l Moreno Camacho</li>
	<li>FUNDAY&Uacute;DANOS</li>
</ul>
</div>
</div>
</div>
</div>
</main>

<footer>
<div class="subscribe subscribe_theme">
<form class="subscribe__item form" id="form" method="POST">
<div class="register-text">Registrese para recibir un<br />
bolitin</div>
<input class="form__email" id="email" name="email" placeholder="Introduce tu correo electronico" type="email" /><input class="form__submit button button_theme_dark" id="submit" type="submit" value="Suscribir" /></form>
</div>

<div class="social">
<div id="fheading">
<h4 font-weight:bold=""><span>LEAN EN LAS REDES SOCIALES</span></h4>
</div>

<div class="icons"></div>

<div id="bottom">
<p><small>Copyright @2019 All rights reserved | This web is made with by <span style="color: #FFC300">DiazApps</span></small></p>
</div>
</div>
</footer>
</div>
</body>
</html>