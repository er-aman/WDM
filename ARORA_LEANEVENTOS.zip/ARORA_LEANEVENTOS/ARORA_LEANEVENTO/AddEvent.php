<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="HomeAgentLean.php">Inicio</a>
        <a href="AgentListIndividual.php" >Lista de Voluntarios</a>
        <a href="AgentListBusiness.php">Lista de Fundaciones</a>
        <a href="" id="active">Eventos</a>
        <a href="AgentProfile.php">Agente</a>
      </li>
    </ul>
  </nav>
</header>

<main>
  <div class= "container-image ">
    <img src="imagenes\bannerregistro.jpg"/>
    <div class="headCenter"><h1 style="margin: 0px;">REGISTRO DE EVENTO</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">EVENTOS</span> &nbsp; REGISTRO</div>
  </div>

  <div id="profileForm" style="position: relative;top: 100px">
    <h3>Registro de Evento</h3>
    <form name="message">
      <div class="info-container">
    <div class="prof"><label  class="slabels"for="mail">Nombres </label>
    <input class="c-input-field " id="mail" type="email" value="" name="mail" placeholder=" Nombre del Evento"><label  class="slabels"for="mail"> Responsable </label>
    <input class="c-input-field " id="mail" type="email" value="" name="mail" placeholder="Nombre de Responsable">  </div>
    <div class="prof" style="line-height: 2.5rem"></div>
    <div class="prof"><img src="imagenes\imagensubir.png" height='200px' width="70%"/> <br/><button class="signbutton" style="text-align: center; width: 70%; font-weight:bold">Seleccionar Imagen
</button></div>
  </div>
  <div style="float:left;margin-right:40px; position: relative;top: 240px">
    <label  class="slabels"for="add">Lugar</label>
    <input class="stretched " id="add" style="width: 1060px" type="text" value="" name="add" placeholder="Direccion del Lugar del Eventos">
  </div>
    <div class="info-container" style=" position: relative;top: 200px">
    <div class="prof"><label  class="slabels"for="mail">Fecha</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="00/00/0000"> </div>
    <div class="prof"><label  class="slabels"for="mail">Hora</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="00:00"> </div>
    <div class="prof"><label  class="slabels"for="mail">Valor de Boleto</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="$000.00"> </div>
  </div>
  <div style=" position: relative; top: 380px; transform: translateX(45%);"><button class="signbutton" style="text-align: center;">Guardar Cambios
</button></div>  
  </form>
  </div>
  </main>

<footer>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>
</div>
</footer>
</body>

</html>