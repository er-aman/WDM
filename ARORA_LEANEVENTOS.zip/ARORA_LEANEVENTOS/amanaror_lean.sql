-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 15, 2019 at 06:45 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lean`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `firstname` varchar(15) NOT NULL,
  `surname` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `topic` varchar(20) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`firstname`, `surname`, `email`, `topic`, `message`) VALUES
('aman', 'arora', 'aman@gmail.com', 'good', 'better luck!!!');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_id` int(100) NOT NULL,
  `event_name` varchar(40) NOT NULL,
  `responsible` varchar(40) NOT NULL,
  `date` varchar(10) NOT NULL,
  `time` varchar(10) NOT NULL,
  `ticket_value` varchar(10) NOT NULL,
  `description` text NOT NULL,
  `image` text NOT NULL,
  `agent_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `event_name`, `responsible`, `date`, `time`, `ticket_value`, `description`, `image`, `agent_id`) VALUES
(29, 'Chid Welfare donation Camp', 'Mr. Mike Siok', '02/03/2016', '04:36', '300', 'Dallas', 'child.jpg', 3),
(30, 'Flood Relief Camp for Victims', 'Mr. Mukesh', '07/09/2019', '04:56', '200', 'Arlington', 'non.jpg', 3),
(31, 'Medicines collection Day', 'Mr. Jhon Smith', '05/08/2019', '09:25', '500', 'Fort Worth', 'keep.jpg', 3),
(32, 'Make the Earth Better', 'Mr. Simon', '08/09/2019', '08:56', '300', 'Austin', 'social.png', 3);

-- --------------------------------------------------------

--
-- Table structure for table `event_foundation`
--

CREATE TABLE `event_foundation` (
  `e_id` int(10) NOT NULL,
  `event_name` varchar(40) NOT NULL,
  `org_mail` varchar(40) NOT NULL,
  `org_name` varchar(40) NOT NULL,
  `commision` float NOT NULL,
  `image` varchar(100) NOT NULL,
  `evt_id` int(10) NOT NULL,
  `org_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_foundation`
--

INSERT INTO `event_foundation` (`e_id`, `event_name`, `org_mail`, `org_name`, `commision`, `image`, `evt_id`, `org_id`) VALUES
(1, 'No Perdamos La Fe', 'jhon.standman@mavs.uta.edu ', 'Big Brothers ', 2.3, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `event_individual`
--

CREATE TABLE `event_individual` (
  `e_id` int(10) NOT NULL,
  `event_name` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `telephone` int(10) NOT NULL,
  `responsible` varchar(30) NOT NULL,
  `image` varchar(10) NOT NULL,
  `evt_id` int(10) NOT NULL,
  `u_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `found_sub`
--

CREATE TABLE `found_sub` (
  `sub_id` int(11) NOT NULL,
  `event_name` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `resp` varchar(100) NOT NULL,
  `date` varchar(10) NOT NULL,
  `time` varchar(10) NOT NULL,
  `image` varchar(100) NOT NULL,
  `event_id` varchar(11) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `comm` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `found_sub`
--

INSERT INTO `found_sub` (`sub_id`, `event_name`, `place`, `resp`, `date`, `time`, `image`, `event_id`, `user_id`, `comm`) VALUES
(6, 'Make the Earth Better', 'Austin', 'Mr. Simon', '08/09/2019', '08:56', 'social.png', '32', '2', '0'),
(7, 'Medicines collection Day', 'Fort Worth', 'Mr. Jhon Smith', '05/08/2019', '09:25', 'keep.jpg', '31', '2', '0');

-- --------------------------------------------------------

--
-- Table structure for table `individual_sub`
--

CREATE TABLE `individual_sub` (
  `sub_id` int(10) NOT NULL,
  `event_name` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `event_id` varchar(11) NOT NULL,
  `user_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lean_users`
--

CREATE TABLE `lean_users` (
  `u_id` int(100) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `password` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(15) NOT NULL,
  `state` varchar(10) NOT NULL,
  `postal_code` int(5) NOT NULL,
  `picture` text NOT NULL,
  `telephone` int(10) NOT NULL,
  `user_name` varchar(15) NOT NULL,
  `foundation_name` varchar(15) NOT NULL,
  `business_type` varchar(12) NOT NULL,
  `role_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lean_users`
--

INSERT INTO `lean_users` (`u_id`, `mail`, `password`, `first_name`, `surname`, `address`, `city`, `state`, `postal_code`, `picture`, `telephone`, `user_name`, `foundation_name`, `business_type`, `role_id`) VALUES
(1, 'amanks@gmail.com', 'veerji', 'Amanji', 'Ank', '400 South Oak Street, Apartment 101', 'Arlington ', 'Texas ', 76010, '49530434_10213228052991032_2857651551181209600_n.jpg', 6511, 'amanji', '', '', 1),
(2, 'aman@gmail.com', 'pitajidata', 'Aman', 'Arora', 'whatsup', 'we good', 'Escoger', 12345, '49530434_10213228052991032_2857651551181209600_n.jpg', 2147483647, 'veerji', '', 'B3', 2),
(3, '13@yahoo.com', 'amank', 'Ankita', 'Arora ', '#28 Sector-20', 'Panchkula ', 'Escoger', 134116, '183198_1573390664764_1124298_n.jpg', 0, 'wow1', '', 'B2', 3),
(4, 'amanji@yahoo.com', 'anky', 'Aman', 'Arora', '114', 'Arlington', '', 76010, 'Screenshot 2019-03-30 at 4.39.11 AM.png', 0, 'wow2', '', '', 1),
(5, 'Jayesh@gmail.com', 'mans,mas', 'm,nasm', 'Arora', '400 South Oak Street Apt 101', 'Arlington', '', 76010, 'user.png', 0, '', '', '', 1),
(6, 'Jayesh@gmail.com', 'mans,mas', 'm,nasm', 'Arora', '400 South Oak Street Apt 101', 'Arlington', '', 76010, 'user.png', 0, '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `city` varchar(10) NOT NULL,
  `state` varchar(10) NOT NULL,
  `postal` varchar(10) NOT NULL,
  `quant` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `event_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `name`, `surname`, `address`, `phone`, `city`, `state`, `postal`, `quant`, `email`, `event_id`) VALUES
(1, '0', '0', '0', '0', '0', '0', '0', '0', '0', 0),
(2, '0', '0', '0', '0', 'Arlington', '0', '76010', '0', 'Jayesh@gmail.com', 0),
(3, '76013-6657', 'Arora', 'Meadow Run, 501 Summit Avenue', '0', 'Arlington', '0', '12345', '0', 'Jayesh@gmail.com', 0),
(4, '76013-6657', 'Arora', 'Meadow Run, 501 Summit Avenue', '0', 'Arlington', '0', 'bhvghfh', '0', 'Jayesh@gmail.com', 0),
(5, '76013-6657', 'Arora', 'Meadow Run, 501 Summit Avenue', '0', 'Arlington', '0', '11111', '0', 'Jayesh@gmail.com', 22),
(6, '76013-6657', 'Arora', 'Meadow Run, 501 Summit Avenue', '29379846', 'Arlington', '0', '76010', '0', 'Jayesh@gmail.com', 22),
(7, '76013-6657', 'Arora', 'Meadow Run, 501 Summit Avenue', '29379846', 'Arlington', '0', '76010', '', 'Jayesh@gmail.com', 22),
(8, '76013-6657', 'Arora', 'Meadow Run, 501 Summit Avenue', '29379846', 'Arlington', '0', '76010', '', 'Jayesh@gmail.com', 22),
(9, '76013-6657', 'Arora', 'Meadow Run, 501 Summit Avenue', '29379846', 'Arlington', '0', '12345', '', 'Jayesh@gmail.com', 22),
(10, '76013-6657', 'Arora', 'Meadow Run, 501 Summit Avenue', '29379846', 'mm,nmn', '0', 'bhvghfh', 'Arlington', 'amanji@yahoo.com', 22),
(11, '76013-6657', 'Arora', 'Meadow Run, 501 Summit Avenue', '29379846', 'mm,nmn', '0', 'bhvghfh', '', 'amanji@yahoo.com', 22),
(12, '76013-6657', 'bhai', 'Meadow Run, 501 Summit Avenue', '29379846', 'Gujrat', '0', '12345', 'x', 'amanji@yahoo.com', 22),
(13, '12345', 'bhai', 'Surat', '29379846', 'Arlington', 'Escoger', '76010', '1', 'Jayesh@gmail.com', 22),
(14, '76010', '8283798', 'b nb n', '29379846', 'Arlington', 'Escoger', '76010', '5', 'bvccbv@gmail.com', 22),
(15, '76010', '8283798', 'b nb n', '29379846', 'Arlington', 'Escoger', '76010', '5', 'bvccbv@gmail.com', 22),
(16, '76010', 'bhai', 'Opposite UTA BookStore', '29379846', 'Arlington', 'Escoger', '76010', '4', 'Jayesh@gmail.com', 22),
(17, '76010', 'Arora', '114', '29379846', 'mm,nmn', 'Escoger', 'bhvghfh', '3', 'amanji@yahoo.com', 22),
(18, '76010', 'Arora', 'b nb n', '29379846', 'Arlington', 'Escoger', '76010', '9', 'bvccbv@gmail.com', 22),
(19, '76010', 'bhai', '400 South Oak Street Apt 101', 'mn,n,', 'Gujrat', 'Escoger', '12345', '6', 'Jayesh@gmail.com', 22),
(20, '12345', 'cvbxvx', 'Surat', '29379846', 'mm,nmn', 'Escoger', 'bhvghfh', '6', 'Jayesh@gmail.com', 22),
(21, '76010', 'cvbxvx', 'b nb n', '29379846', 'Arlington', 'Escoger', '76010', '1', 'bvccbv@gmail.com', 22),
(22, 'amanji@yahoo.com', 'Arora', 'jnm', '29379846', 'mm,nmn', 'Escoger', 'bhvghfh', '1', 'mn@hmm.vom', 22);

-- --------------------------------------------------------

--
-- Table structure for table `subsciption`
--

CREATE TABLE `subsciption` (
  `email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subsciption`
--

INSERT INTO `subsciption` (`email`) VALUES
('vipin.bansal@mavs.uta.edu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `event_foundation`
--
ALTER TABLE `event_foundation`
  ADD PRIMARY KEY (`e_id`),
  ADD UNIQUE KEY `org_mail` (`org_mail`);

--
-- Indexes for table `event_individual`
--
ALTER TABLE `event_individual`
  ADD PRIMARY KEY (`e_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `found_sub`
--
ALTER TABLE `found_sub`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `individual_sub`
--
ALTER TABLE `individual_sub`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `lean_users`
--
ALTER TABLE `lean_users`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `subsciption`
--
ALTER TABLE `subsciption`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `event_foundation`
--
ALTER TABLE `event_foundation`
  MODIFY `e_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `event_individual`
--
ALTER TABLE `event_individual`
  MODIFY `e_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `found_sub`
--
ALTER TABLE `found_sub`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `individual_sub`
--
ALTER TABLE `individual_sub`
  MODIFY `sub_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `lean_users`
--
ALTER TABLE `lean_users`
  MODIFY `u_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
