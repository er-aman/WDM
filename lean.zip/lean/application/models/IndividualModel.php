<?php
/**
 * 
 */
class IndividualModel extends CI_Model
{
	public function UpdateProfile(){
 
		$data = array('first_name' => $this->input->post('name'),
		'surname' => $this->input->post('surname'),
		'mail' => $this->input->post('mail'),
		'telephone' => $this->input->post('phone'),
		'user_name' => $this->input->post('u_name'),
		'password' => $this->input->post('u_password')
		);
		$user_id = $this->session->userdata('u_id');
		$this->db->where('u_id',$user_id);
		$result = $this->db->update('lean_users',$data);
		if($result){
			return true;
		}else{
			return false;
		}

	}
	public function getEvnts(){
		$u_id =$this->session->userdata('u_id');
		$check_evt = $this->db->get_where('individual_sub',['user_id'=>$u_id]);
		if($check_evt->num_rows() > 0){
					return $check_evt->result();
				}else{
					return $check_evt->result();
				}
	}
	public function ListEvents(){
		$get_event = $this->db->select()
				->from('event')
				->order_by('event_id','desc')
				->get();
				if($get_event->num_rows() > 0){
					return $get_event->result();
				}else{
					return $get_event->result();
				}
	}
	public function AddUserEvent($eventID){
		$u_id =$this->session->userdata('u_id');
		$check_evt = $this->db->get_where('individual_sub',['event_id'=>$eventID]);
		if($check_evt->num_rows() !=0){
			return false;
		}else{
			 $data= $this->db->get_where('event',array('event_id'=>$eventID));
			 $myEvents= $data->result();
			 $name = $myEvents[0]->event_name;
			 $des = $myEvents[0]->description;
			 $res = $myEvents[0]->responsible;
			 $date = $myEvents[0]->date;
			 $time= $myEvents[0]->time;
			 $image = $myEvents[0]->image;
			 $event_id = $myEvents[0]->event_id;
			 // echo '<pre>';
    // print_r($name);
    // echo '</pre>';
    // echo '<pre>';
    // print_r($res);
    // echo '</pre>';
    // echo '<pre>';
    // print_r($date);
    // echo '</pre>';
    // echo '<pre>';
    // print_r($time);
    // echo '</pre>';
    // echo '<pre>';
    // print_r($image);
    // echo '</pre>';
    // echo '<pre>';
    // print_r($event_id);
    // echo '</pre>';
			 
			$data = array('event_name'=> $name,
				'place'=>$des,
				'date'=>$date,
				'time'=>$time,
				'image'=>$image,
				'event_id'=>$event_id,
				'user_id'=>$u_id
			);

			$res= $this->db->insert('individual_sub',$data);
			if($res){
				return true;
			}else{
				return false;
			}
		}

	}
	public function UserDetails(){
		$u_id =$this->session->userdata('u_id');
		$data= $this->db->get_where('lean_users',array('u_id'=>$u_id));
		return $data->result();
	}
}

?>