<?php
/**
 * 
 */
class HomeModel extends CI_Model
{
	public function Contacto(){
 
		$data = array('firstname' => $this->input->post('name'),
		'surname' => $this->input->post('surname'),
		'email' => $this->input->post('email'),
		'topic' => $this->input->post('topic'),
		'message' => $this->input->post('message')
		);

		$insert_user =$this->db->insert('contact_us',$data);
		if($insert_user){
			return true;
		}else{
			return false;
		}

	}
	public function Buy(){
		$query = $this->db->get('event'); 
		if($query->num_rows() > 0){
					return $query->result();
				}
	}
	public function Inside($id){
		$get_event =$this->db->get_where('event',array('event_id'=>$id));
				if($get_event->num_rows() > 0){
					return $get_event->result();
				}else{
					return $get_event->result();
				}
	}
}

?>