<?php
/**
 * 
 */
class AgentModel extends CI_Model
{
	public function AddEvent($data){
// 		if(isset($_POST['update'])){
// 	  $u_img .= basename($_FILES['u_image']['name']);
// 	  $u_img_tmp = $_FILES['u_image']['tmp_name'];
// 	  $folder = "base_url('imagenes/');";
// 	  move_uploaded_file($u_img_tmp, $folder .$u_img);
// }
		$result = $this->db->insert('event',$data);
		if($result){
			return true;
		}else{
			return false;
		}

	}
	public function UserDetails(){
		$u_id =$this->session->userdata('u_id');
		$data= $this->db->get_where('lean_users',array('u_id'=>$u_id));
		return $data->result();
	}
	public function AgentEvevnts(){
		$u_id =$this->session->userdata('u_id');
		$get_event =$this->db->get_where('event',array('agent_id'=>$u_id));
				if($get_event->num_rows() > 0){
					return $get_event->result();
				}else{
					return $get_event->result();
				}
	}
	public function DeleteEvent($eventID){
		$u_id =$this->session->userdata('u_id');
  		$this -> db -> delete('event',array('event_id'=>$eventID,'agent_id' =>$u_id));
	}
	public function MoEvevnts($eventID){
		$u_id =$this->session->userdata('u_id');
		$check_evt = $this->db->get_where('event',array('event_id'=>$eventID,'agent_id'=>$u_id));
		if($check_evt->num_rows() > 0){
					return $check_evt->result();
				}
	}
	public function EvUpdated($data){
		$u_id =$this->input->post('event_id');
		$this->db->where('event_id', $u_id);
		$result = $this->db->update('event',$data);
		if($result){
			return true;
		}else{
			return false;
		}
	}
	public function BDetails(){
		$query = $this->db->get('found_sub'); 
		if($query->num_rows() > 0){
					return $query->result();
				}
	}

}

?>