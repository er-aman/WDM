<?php
/**
 * 
 */
class UserModel extends CI_Model
{
	public function InsertUser(){
 
		$data = array('mail' => $this->input->post('mail'),
		'password' => $this->input->post('password'),
		'first_name' => $this->input->post('name'),
		'surname' => $this->input->post('surname'),
		'address' => $this->input->post('add'),
		'city' => $this->input->post('city'),
		'state' => $this->input->post('state'),
		'postal_code' => $this->input->post('postal'),
		'picture' =>'user.png',
		'telephone' =>'',
		'user_name' =>'',
		'foundation_name' =>'',
		'business_type' =>'',
		'role_id' => $this->input->post('roleId')

		);

		$insert_user =$this->db->insert('lean_users',$data);
		if($insert_user){
			return true;
		}else{
			return false;
		}

	}
		public function Login(){
			$mail = $this->input->post('u_mail');
			$Password = $this->input->post('u_password');

			$this->db->where('mail', $mail);
			$this->db->where('password',$Password);
			$result = $this->db->get('lean_users');
			if($result->num_rows()==1){
				return $result;
			}else{
				return false;
			}
	}
}

?>