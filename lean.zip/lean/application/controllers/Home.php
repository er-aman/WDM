<?php
/**
 * 
 */
class Home extends CI_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('User/UserModel','um');
		$this->load->model('HomeModel','hm');
		$this->load->model('IndividualModel','Im');
	}
	public function index(){
		$this->load->view('header');
		$this->load->view('Home/index');
		$this->load->view('footer');
	}
	public function loginView(){
		$this->load->view('header');
		$this->load->view('login_view');
		$this->load->view('footer2');

	}
	public function login(){
		$this->form_validation->set_rules('u_mail','Email','trim|required|regex_match[/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/]');
		$this->form_validation->set_rules('u_password','Password','trim|required|min_length[8]');
		if($this->form_validation->run() == FALSE){
			$data = array('errors'=>validation_errors());
			$this->session->set_flashdata($data);
		}else{
			$username = $this->input->post('u_mail');
			$Password = $this->input->post('u_password');
			$result = $this->um->Login();
			if($result){
				foreach ($result->result_array() as $row)
						{
						        $type= $row['role_id'];
						        $user_mail = $row['mail'];
						        $u_id = $row['u_id'];
						}
				$session_data = array(
					'user_mail' => $user_mail,
					'u_id' => $u_id,
					'type' => $type
				);
				$this->session->set_userdata($session_data); 
				if($type=='1'){
					redirect('Home/Individual');
				}elseif($type=='2'){
					redirect('Home/Business');
				}elseif($type=='3'){
					redirect('Home/Agent');
				}
			}else{
				redirect('Home/loginView');
			}
		}
	}
	public function Individual(){
		if($this->session->userdata('u_id')==" " || $this->session->userdata('type')!=" 1" ){
			redirect('Home/loginView');
		}else{
		$result=$this->Im->ListEvents();
		$this->load->view('Individual/IndividualHeader');
		$this->load->view('Individual/HomeIndividual',['events' => $result]);
		$this->load->view('footer3');
		}
	}
	public function Business(){
		if($this->session->userdata('u_id')==" " || $this->session->userdata('type')!=" 2" ){
			redirect('Home/loginView');
		}else{
		$this->load->view('Business/IndividualHeader');
		$this->load->view('Business/HomeIndividual');
		$this->load->view('footer3');
		}
	}
	public function Agent(){
		if($this->session->userdata('u_id')==" " || $this->session->userdata('type')!=" 3" ){
			redirect('Home/loginView');
		}else{
		$this->load->view('Agent/AgentHeader');
		$this->load->view('Agent/HomeAgent');
		$this->load->view('footer3');
		}
	}
	public function Contact(){
		$this->load->view('header');
		$this->load->view('ContactUs');
		$this->load->view('footer2');
	}
	public function BuyFromUs(){
		$result=$this->hm->Buy();
		$this->load->view('header');
		$this->load->view('Home/BuyFromUs',['buy' => $result]);
		$this->load->view('footer');
	}
	public function Pro($id){
		$result=$this->hm->Inside($id);
		$this->load->view('header');
		$this->load->view('Home/ProDetails',['evnt' => $result]);
		$this->load->view('footer');
	}
	public function About(){
		$this->load->view('header');
		$this->load->view('Home/About');
		$this->load->view('footer');
	}
	public function ContactUs(){
		$this->form_validation->set_rules('name','Name','trim|required');
		$this->form_validation->set_rules('surname','Surname','trim|required');
		$this->form_validation->set_rules('email','Email','trim|required|regex_match[/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/]');
		$this->form_validation->set_rules('topic','Topic','trim|required');
		$this->form_validation->set_rules('message','Message','trim|required');
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		if($this->form_validation->run()== FALSE){
			$data = array('errors' => validation_errors());
			$this->session->set_flashdata($data);
			$this->load->view('ContactUs');
		}else{
			$result=$this->hm->Contacto();
			if($result){
				redirect('Home/index');
			}
		}
	}
}

?>