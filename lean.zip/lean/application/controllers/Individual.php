<?php

/**
 * 
 */
class Individual extends CI_Controller
{
	
	public function __construct()
	{
		parent:: __construct();
		$this->load->model('Individualmodel','Im');
		$this->load->model('AgentModel','am');
	}
	public function Logout(){
		$this->session->unset_userdata('user_mail');
		$this->session->unset_userdata('u_id');
		$this->session->unset_userdata('type');
		redirect('Home/index');
	}
	public function IndividualProfile(){
		$data=$this->am->UserDetails();
		$this->load->view('Individual/IndividualHeader');
		$this->load->view('Individual/IndividualProfile',['details'=>$data]);
		$this->load->view('footer3');
	}
	public function update(){
		$this->form_validation->set_rules('name','Name','trim|required');
		$this->form_validation->set_rules('surname','Surname','trim|required');
		$this->form_validation->set_rules('mail','Email','trim|required|regex_match[/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/]');
		$this->form_validation->set_rules('phone','Phone','trim|required|regex_match[/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/]');
		$this->form_validation->set_rules('u_name','Username','trim|required');
		$this->form_validation->set_rules('u_password','Password','trim|required|min_length[8]');
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		if($this->form_validation->run()== FALSE){
			$data = array('errors' => validation_errors());
			$this->session->set_flashdata($data);
			$this->load->view('ContactUs');
		}else{
			$result=$this->Im->UpdateProfile();
			if($result){
				redirect('Individual/IndividualProfile');
			}
		}
	}
	public function UserEvents($eventId){
		$result=$this->Im->AddUserEvent($eventId);
		if($result){
			redirect('Individual/myEvents');
		}else {
			echo "<script language=\"javascript\">alert('Event Already Added');</script>";
		}
	}
	// public function ShowEvents(){
	// 	if($this->session->userdata('type') != '1' || $this->session->userdata('type') ==''){
	// 		return redirect('Home/index');
	// 	}else{
	// 		$result=$this->Im->ListEvents();
	// 	}
	// }
	public function myEvents(){
		$res=$this->Im->getEvnts(); 
		$this->load->view('Individual/IndividualHeader');
		$this->load->view('Individual/MyEvents',['evnts'=>$res]);
		$this->load->view('footer3');
}
}

?>