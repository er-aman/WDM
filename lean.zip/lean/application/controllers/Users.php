<?php

/**
 * 
 */
class Users extends CI_Controller
{
	
	public function __construct()
	{
		parent:: __construct();
		$this->load->model('User/UserModel','um');
	}

	public function index(){
		$this->load->view('header');
		$this->load->view('Users/index');
	}
	public function CreateUser(){

		$this->form_validation->set_rules('mail','Email','trim|required|regex_match[/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/]');
		$this->form_validation->set_rules('password','Password','trim|required|min_length[8]');
		$this->form_validation->set_rules('name','Name','trim|required');
		$this->form_validation->set_rules('surname','Surname','trim|required');
		$this->form_validation->set_rules('add','Address','trim|required');
		$this->form_validation->set_rules('city','City','trim|required');
		$this->form_validation->set_rules('postal','Postal','trim|required');

		if($this->form_validation->run() == FALSE){
			$data = array('errors' => validation_errors());
			$this->session->set_flashdata($data);
			redirect('Users/index');
		}else{
			$result = $this->um->InsertUser();
			if(result){
				redirect('Home/index');
			}else{
				redirect('Users/index');
			}
		 }
	}
	public function subscribe(){
		$sub_mail = $this->input->post('email');
		$config['charset'] ='utf-8';
		$config['mailtype'] ='html';
		$this->email->initialize($config);
		$this->email->to($sub_mail);
		$this->email->from('aman.cqu@gmail.com');
		$this->email->subject('Welcome to LeanEvento');
		$this->email->message('Thanks for subscribing!!! Welcome to LeanEventos.');
		if($this->email->send()){
			redirect('Home/index');
		}
	}
}

?>