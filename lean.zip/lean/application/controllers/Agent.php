<?php

/**
 * 
 */
class Agent extends CI_Controller
{
	
	public function __construct()
	{
		parent:: __construct();
		$this->load->model('AgentModel','am');
		$this->load->model('IndividualModel','Im');
	}
	public function Logout(){
		$this->session->unset_userdata('u_id');
		redirect('Home/index');
	}
	public function AddEv(){
		$this->load->view('Agent/AgentHeader');
		$this->load->view('Agent/AddEvent');
		$this->load->view('footer3');
	}
	public function AgentProfile(){
		$data=$this->am->UserDetails();
		$this->load->view('Agent/AgentHeader');
		$this->load->view('Agent/AgentProfile',['details'=>$data]);
		$this->load->view('footer3');
	}
	public function Eventos(){
		$data=$this->am->AgentEvevnts();
		$this->load->view('Agent/AgentHeader');
		$this->load->view('Agent/Eventos',['evnt'=>$data]);
		$this->load->view('footer3');
	}

	public function UpEvt(){
	
		$this->form_validation->set_rules('name','Name','trim|required');
		$this->form_validation->set_rules('surname','Responsable','trim|required');
		$this->form_validation->set_rules('mail','Lugar','trim|required');
		$this->form_validation->set_rules('phone','Fecha','trim|required');
		$this->form_validation->set_rules('u_name','Hora','trim|required');
		$this->form_validation->set_rules('u_password','Price','trim|required');
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		if($this->form_validation->run()== FALSE){
			$this->load->view('Agent/Modify');
		}else{
		
		$config =['upload_path'=> './imagenes',
		'allowed_types'=> 'jpg|jpeg|png'];
		// $config['file_name'] = $_FILES['u_image']['name'];
		$this->load->library('upload',$config);
		if($this->upload->do_upload('u_image')){
			$data= $this->input->post();
			$info= $this->upload->data();
		// 	echo '<pre>';
		// print_r($this->upload->data());
		// echo '</pre>';
		exit();
		}
		$filename= $this->upload->data();
		$img_name =$filename['file_name'];

		$data = array('event_name' => $this->input->post('name'),
		'responsible' => $this->input->post('surname'),
		'date' => $this->input->post('phone'),
		'time' => $this->input->post('u_name'),
		'ticket_value' => $this->input->post('u_password'),
		'description' => $this->input->post('mail'),
		'image'=>$img_name,
		'agent_id'=>$this->session->userdata('u_id')
		);
			$result=$this->am->EvUpdated($data);
			if($result){
				echo "<script language=\"javascript\">alert('Event Updated');</script>";
				redirect('Agent/Eventos');
			
		}
	}
	public function AgentHome(){
		$this->load->view('Agent/AgentHeader');
		$this->load->view('Agent/HomeAgent');
		$this->load->view('footer3');
	}
	
	public function AgentListBusiness(){

		$data=$this->am->BDetails();
		$this->load->view('Agent/AgentHeader');
		$this->load->view('Agent/ListBusiness',['Bdetails'=>$data]);
		$this->load->view('footer3');
	}
	public function Modify($id){
		$data=$this->am->MoEvevnts($id);
		$this->load->view('Agent/AgentHeader');
		$this->load->view('Agent/EditEvent',['evnt'=>$data]);
		$this->load->view('footer3');
	}
	public function AgentListIndividual(){
		$this->load->view('Agent/AgentHeader');
		$this->load->view('Agent/ListIndividual');
		$this->load->view('footer3');
	}
	public function update(){
		$this->form_validation->set_rules('name','Name','trim|required');
		$this->form_validation->set_rules('surname','Surname','trim|required');
		$this->form_validation->set_rules('mail','Email','trim|required');
		$this->form_validation->set_rules('phone','Phone','trim|required');
		$this->form_validation->set_rules('u_name','Username','trim|required');
		$this->form_validation->set_rules('u_password','Password','trim|required|min_length[8]');
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		if($this->form_validation->run()== FALSE){
			$this->load->view('AgentProfile');
		}else{
			$result=$this->Im->UpdateProfile();
			if($result){
				redirect('Agent/AgentProfile');
			}
		}
	}
	public function InsertEvt(){
		$this->form_validation->set_rules('name','Name','trim|required');
		$this->form_validation->set_rules('surname','Responsable','trim|required');
		$this->form_validation->set_rules('mail','Lugar','trim|required');
		$this->form_validation->set_rules('phone','Fecha','trim|required');
		$this->form_validation->set_rules('u_name','Hora','trim|required');
		$this->form_validation->set_rules('u_password','Price','trim|required');
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		if($this->form_validation->run()== FALSE){
			$this->load->view('Agent/AddEvent');
		}else{
		
		$config =['upload_path'=> './imagenes',
		'allowed_types'=> 'jpg|jpeg|png'];
		// $config['file_name'] = $_FILES['u_image']['name'];
		$this->load->library('upload',$config);
		if($this->upload->do_upload('u_image')){
			$data= $this->input->post();
			$info= $this->upload->data();
		exit();
		}else{
			//test
			echo"Unable to upload";
		}
		$filename= $this->upload->data();
		$img_name =$filename['file_name'];

		$data = array('event_name' => $this->input->post('name'),
		'responsible' => $this->input->post('surname'),
		'date' => $this->input->post('phone'),
		'time' => $this->input->post('u_name'),
		'ticket_value' => $this->input->post('u_password'),
		'description' => $this->input->post('mail'),
		'image'=>$img_name,
		'agent_id'=>$this->session->userdata('u_id')
		);

			$result=$this->am->AddEvent($data);
			if($result){
				echo "<script language=\"javascript\">alert('Event Added');</script>";
				redirect('Agent/Eventos');
			}
		}
	}
}

?>