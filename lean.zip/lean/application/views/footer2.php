<footer>
<div class="social">
<div id="fheading"><h4 font-weight:bold"><span>LEAN EN LAS REDES SOCIALES</span></h4></div>
<div class="icons">
<a href="#">
<i class="fa fa-twitter" style="font-size:24px;color:#FFC300"></i> </a>
<a href="#"> <i class="fa fa-facebook"  style="font-size:24px;color:#FFC300"></i></a>
<a href="#"> <i class="fa fa-instagram"style="font-size:24px;color:#FFC300"></i></a>
</div>
<div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
</div>

</div>
</footer>
</body>

</html>
