<header id="header">

</header>
<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
</head>
<main>
  <div class= "container-image ">
    <img src="<?= base_url('imagenes/bannerlogin.jpg'); ?>"/>
    <div class="headCenter"><h1 style="margin: 0px;">INICIAR SESIÓN</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">INICIO</span> &nbsp; INICIAR SESIÓN</div>
  </div>
<div id="form-outer">
  <?php 
  $attributes =array('name' => 'login');
  echo form_open('Home/login',$attributes);
   ?>
 <!--  <form name="login" method="post"> -->
    <p style="padding:10px;">Iniciar sesión</p>
  <div class="form-row">
    <div class="form-group col-md-6">
      <?php
      echo form_label('Nombre de Usuario','inputEmail4');
      ?>
      <?php 
      $data = array('class'=>'form-control', 'id'=>'inputEmail4', 'type'=>'email', 'name'=>'u_mail', 'placeholder'=>'Nombre de Usuario', 'required');
      echo form_input($data);
      ?>
      <!-- <label for="inputEmail4">Nombre de Usuario</label>
      <input class="form-control" id="inputEmail4" type="email" name="u_mail" placeholder="Nombre de Usuario" required> -->
    </div>
    <div class="form-group col-md-6">
       <?php
      echo form_label('Contraseña','inputPassword4');
      ?>
      <?php 
      $data = array('class'=>'form-control', 'id'=>'inputPassword4', 'type'=>'password', 'name'=>'u_password', 'placeholder'=>'Contraseña', 'required');
      echo form_password($data);
      ?>
      <!-- <label for="inputPassword4">Contraseña</label>
      <input type="password" class="form-control" id="inputPassword4" placeholder="Contraseña" name="u_password" required> -->
    </div>
  </div>
  <section>
    <div id="forgot">
      <a href="#indi"><button id="forgotbtn" onclick= "document.getElementById('indi').style.display='block'">olvidó su contraseña?</button></a>
      </div>
      <div id="login">
      <?php 
      $data = array('id'=>'submitBtn','type'=>'submit','value'=>'Entra', 'style'=>'margin-top: 10px', 'name'=>'Login');
      echo form_submit($data);
      ?>
    <!--   <input id="submitBtn" type="submit" value="Entra" style="margin-top: 10px;" name="Login"> -->
      </div>                                                                                       
    </section>
 <!--  <div class="form-row text-center">
    <div class="col-12">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
 </div> -->
</form>
<!-- <form name="login" action="Login.php" method="post">
    <section>
      <p style="padding:10px;">Iniciar sesión</p>
  <div style="float:left;margin-right:20px;">
    <label  class="labels"for="name">Nombre de Usuario</label>
    <input class="input-field " id="name" type="text" name="u_name" required>
  </div>

  <div style="float:left;">
    <label class="labels" for="password">Contraseña</label>
    <input class="input-field " id="pass" type="password" name="u_password" required>
  </div>
    </section>

    <section>
    <div id="forgot">
      <a href="#indi"><button id="forgotbtn" onclick= "document.getElementById('indi').style.display='block'">olvidó su contraseña?</button></a>
      </div>
      <div id="login">
      <input id="submitBtn" type="submit" value="Entra" name="Login">
      </div>                                                                                       
    </section>
</form>
</div> -->
<div id="indi" class="bg">
<form name="message" class="forgotpwd animate">
    <section>
      <p style="padding:5px; margin-top:0;">Recupera tu contraseña</p>
      <hr>
      <form>
  <div class="form-group">
    <label for="formGroupExampleInput">Correo</label>
    <input type="email" class="form-control" id="formGroupExampleInput" value="" name="email" placeholder="Correo">
  </div>
      <hr style="margin-top: 50px">
       <div style="margin: 10px 0px 10px 20px;float:right"class="inner"><button style="background-color:#C0C0C0; color:black; padding:1rem"class="signbutton">Cerrar</button> <button class="signbutton">Enviar</button></div>
    </section>
</form>
</div>
</main>