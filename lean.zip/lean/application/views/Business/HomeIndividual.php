<main>
  <h1 style="text-align: center;">Lista de Eventos</h1>
  <div id="page">
      <table id="cart">
        <thead id="headings">
          <tr>
            <th class="photo">&nbsp</th>
            <th class="event">DETALLES DEL EVENTOS</th>
            <th class="lugar">LUGAR</th>
            <th class="fecha">FECHA</th>
            <th class="hora">HORA</th>
            <th class="asist">ASISTENCIA</th>
          </tr>
        </thead>
        <tbody>
   
        </tbody>
      </table>
    </div>
    <div id="welcome" class="bg">
<form name="message" class="forgotpwd animate">
    <section>
      <h3 style="text-decoration: none; text-align: center;">Bienvenido</h3>
      <hr>
      <p style="text-align: center; font-size: 1.2rem">Gracias por ser un Voluntario en nuestros evento.</p>
      <hr style="margin-top: 50px">
       <div style="margin: 30px 0px 10px 2px;float:right"class="inner"><button style="background-color:#C0C0C0; color:black; padding:10px 20px 10px 20px"class="signbutton">Close</button> </div>
    </section>
</form>
</div>
</main>