<?php if($this->session->flashdata('errors')): ?> 
<!--  <?php echo $this->session->flashdata('errors'); ?> -->

<?php endif; ?>

<?php
// $mailErr=$passwordErr=$nameErr=$surnameErr=$addErr=$cityErr=$stateErr=$postalErr="";
// $mail=$password=$name=$surname=$add=$city=$state=$postal="" ;
// if($_SERVER["REQUEST_METHOD"] == "POST"){
//   if(empty($_POST["mail"])){
//     $mailErr = "Mail id is required.";
//   }else{
//     $mail .=test_input($_POST['mail']);

//     if(!filter_var($mail, FILTER_VALIDATE_EMAIL)){
//       $mailErr = "Invalid email format.";
//     }
//   }
//   if(empty($_POST['password'])){
//     $passwordErr="Password is required";
//   }else{
//     $password .= test_input($_POST['password']);
//   }
//   if(empty($_POST['name'])){
//     $nameErr ="Name is required";
//   }else{
//     $name .= test_input($_POST['name']);
//   }

//   if(empty($_POST['surname'])){
//     $surnameErr = "Surname is required";
//   }else{
//     $surname .= test_input($_POST['surname']);
//   }

//   if(empty($_POST['add'])){
//     $addErr = "Address is required";
//   }else{
//     $add .= test_input($_POST['add']);
//   }
//    if(empty($_POST['city'])){
//     $cityErr = "City is required";
//   }else{
//     $city .= test_input($_POST['city']);
//   }
//    if(empty($_POST['postal'])){
//     $postalErr = "Postal code is required";
//   }else{
//     $postal .= test_input($_POST['postal']);
//   }

// }


// if(isset($_POST['register'])){
 
//   $roleId = $_POST['roleId'];

//   $insert_user = "insert into lean_users(mail,password,first_name,surname,address,city,state,postal_code,picture,telephone,user_name,foundation_name,business_type,role_id) values ('$mail','$password','$name','$surname','$add','$city','$state','$postal','user.png','','','','','$roleId')";
// $reg_user = mysqli_query($con,$insert_user);

// }

// if(isset($_POST['fregister'])){
//   $fmail=$fpassword=$fname=$fsurname=$fadd=$fcity=$fstate=$fpostal=$ftype="";
//   if(isset($_POST['fmail'])){
//     $fmail .= $_POST['fmail'];
//   }
//   if(isset($_POST['fpassword'])){
//     $fpassword .= $_POST['fpassword'];
//   }
//   if(isset($_POST['fname'])){
//     $fname .= $_POST['fname'];
//   }
//   if(isset($_POST['fsurname'])){
//     $fsurname .= $_POST['fsurname'];
//   }
//   if(isset($_POST['fadd'])){
//     $fadd .= $_POST['fadd'];
//   }
//   if(isset($_POST['fcity'])){
//     $fcity .= $_POST['fcity'];
//   }
//   if(isset($_POST['fstate'])){
//     $fstate .= $_POST['fstate'];
//   }
//   if(isset($_POST['fpostal'])){
//     $fpostal .= $_POST['fpostal'];
//   }
//   if(isset($_POST['ftype'])){
//     $ftype .= $_POST['ftype'];
//   }
//   $roleId = $_POST['froleId'];


//   $insert_bUser = "insert into lean_users(mail,password,first_name,surname,address,city,state,postal_code,picture,telephone,user_name,foundation_name,business_type,role_id) values ('$fmail','$fpassword','$fname','$fsurname','$fadd','$fcity','$fstate','$fpostal','','','','','$ftype','$roleId')";
// $reg_user = mysqli_query($con,$insert_bUser);

//}

// function test_input($data){
//   $data = trim($data);
//   $data = stripcslashes($data);
//   $data = htmlspecialchars($data);
//   return $data;
// }

?>

<!DOCTYPE html>

<html>

<head>
  <!-- <script>
    function formValidation(){
      var mail = document.forms["message"]["mail"];
      var password = document.forms["message"]["password"];
      var name = document.forms["message"]["name"];
      var surname = document.forms["message"]["surname"];
      var add = document.forms["message"]["add"];
      var city = document.forms["message"]["city"];
      var state = document.forms["message"]["state"];
      var postal = document.forms["message"]["postal"];

      if(mail.value == ""){
        window.alert("Please enter your Correo");
        mail.focus();
        return false;
      }
      if(password.value == ""){
        window.alert("Please enter your Contraseña");
        password.focus();
        return false;
      }
      if(name.value == ""){
        window.alert("Please enter your Nombre");
        name.focus();
        return false;
      }
      if(surname.value == ""){
        window.alert("Please enter your Apellido");
        surname.focus();
        return false;
      }
      if(add.value == ""){
        window.alert("Please enter your Direccion");
        add.focus();
        return false;
      }
      if(city.value == ""){
        window.alert("Please enter your Ciudad");
        city.focus();
        return false;
      }
      if(state.value == ""){
        window.alert("Please select your Esatado");
        state.focus();
        return false;
      }
      if(postal.value == ""){
        window.alert("Please enter your Código postal");
        postal.focus();
        return false;
      }
      return true;
    }

    function validfoundation(){
      var mail = document.forms['fmessage']['fmail'];
      var password = document.forms["fmessage"]["fpassword"];
      var name = document.forms["fmessage"]["fname"];
      var surname = document.forms["fmessage"]["fsurname"];
      var add = document.forms["fmessage"]["fadd"];
      var city = document.forms["fmessage"]["fcity"];
      var state = document.forms["fmessage"]["fstate"];
      var postal = document.forms["fmessage"]["fpostal"];
      var btype = document.forms['fmessage']['ftype'];

      if(mail.value == ""){
        window.alert("Please enter your Correo");
        mail.focus();
        return false;
      }
      if(password.value == ""){
        window.alert("Please enter your Contraseña");
        password.focus();
        return false;
      }
      if(name.value == ""){
        window.alert("Please enter your Nombre");
        name.focus();
        return false;
      }
      if(surname.value == ""){
        window.alert("Please enter your Apellido");
        surname.focus();
        return false;
      }
      if(add.value == ""){
        window.alert("Please enter your Direccion");
        add.focus();
        return false;
      }
      if(city.value == ""){
        window.alert("Please enter your Ciudad");
        city.focus();
        return false;
      }
      if(state.value == ""){
        window.alert("Please select your Esatado");
        state.focus();
        return false;
      }
      if(postal.value == ""){
        window.alert("Please enter your Código postal");
        postal.focus();
        return false;
      }
      if(btype.value == ""){
        window.alert("Please select your business type.");
        postal.focus();
        return false;
      }
      return true;
    }

  </script> -->
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <?=link_tag('CSS/leanevent.css'); ?>
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body>
<div id="wrapper">
<header id="header">
  <!-- <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="home.php" >Inicio</a>
        <a href="AboutUs.php">Quienes Somos</a>
        <a href="http://amanarora.uta.cloud/blog/">Blog</a>
        <a href="signUp.php" id="active">Registrate</a>
        <a href="Contact.php">Contacto</a>
        <a href="Login.php">Iniciar Sesion</a>
        <a href="BuyFromUs.php">Comprar Boletos</a></li>

      </li>
    </ul>
  </nav> -->
</header>

<main>
  <div class= "container-image ">
    <img src="<?= base_url('imagenes/bannerregistro.jpg'); ?>"/>
    <div class="headCenter"><h1 style="margin: 0px;">REGÍSTRATE</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">INICIO</span> &nbsp; REGÍSTRATE</div>
  </div>
  <div id="form-outer">
    <p style="padding:10px;">Elija el tipo de usuario para registrarse</p>
    <div id="box">
      <div class="btn-toolbar">
  <button type="button" class="btn btn-outline-warning signbutton"  style="margin-left: 25px; background-color: #FFC300; color:#ffffff" onclick= "document.getElementById('indi').style.display='block'">Como individual</button>
  <button type="button" class="btn btn-outline-warning signbutton" style="margin-left: 25px; background-color: #FFC300; color:#ffffff "onclick= "document.getElementById('biz').style.display='block'">Como Negocio o Fundacion</button>
  <button type="button" class="btn btn-outline-warning signbutton" style="margin-left: 25px; background-color: #FFC300; color:#ffffff " onclick= "document.getElementById('agent').style.display='block'">Como agenta LEAN</button>
</div>
    </div> 
</div>
<div id="indi" class="bg">
  <?php $attributes = array('class' => 'individual animate', 'style' => 'height:800px','onsubmit' => 'return formValidation()'); ?>
  <?php echo form_open('Users/CreateUser',$attributes); ?>
<!-- <form name="message" class="individual animate"  onsubmit="return formValidation()" method="post" enctype="multipart/form-data"  style="height:800px"> -->
    <section>
      <p class="form-heading" style="text-align: left;text-decoration: none; color: black">Registro Individual</p>
      <hr>
       <div class="form-row">
    <div class="form-group col-md-6">
      <?php 
      $d1= array('id'=>'roleId','name'=>'roleId','type'=>'hidden','value'=>'1');
       ?>
       <?php echo form_input($d1)?>



      <!-- <input id="roleId" name="roleId" type="hidden" value="1"> -->
      
      <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Correo','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'email', 'class'=>'form-control', 'id'=>'inputEmail4', 'name'=>'mail', 'placeholder'=>'Correo', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
       <?php echo form_error('mail'); ?>
      <!-- <label for="inputEmail4" style="padding-left: 20px; ">Correo</label>
      <input type="email" class="form-control" id="inputEmail4" name="mail" placeholder="Correo" required style="margin-left: 20px;max-width:84%">  -->
      <!-- <span><?php echo $mailErr;?></span> -->
    </div>
    <div class="form-group col-md-6">
       <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Contraseña','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'password', 'class'=>'form-control', 'id'=>'inputEmail4', 'name'=>'password', 'placeholder'=>'Contraseña', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
      <!-- <label for="inputEmail4" style="padding-left: 20px; ">Contraseña</label>
      <input  class="form-control" id="inputEmail4" type="password" name="password" placeholder="Contraseña" required style="margin-left: 20px;max-width:84%"> <span><?php echo $passwordErr;?></span> -->
    </div>
  </div>
      <div class="form-row">
    <div class="form-group col-md-6">
      <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Nombre','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'text', 'class'=>'form-control', 'id'=>'inputEmail4', 'name'=>'name', 'placeholder'=>'Nombre', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
      <!-- <label for="inputEmail4" style="padding-left: 20px; ">Nombre</label>
      <input  class="form-control" id="inputEmail4" type="text" name="name"placeholder="Nombre" required style="margin-left: 20px;max-width:84%"> <span><?php echo $mailErr;?></span> -->
    </div>
    <div class="form-group col-md-6">
        <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Apellido','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'text', 'class'=>'form-control', 'id'=>'inputEmail4', 'name'=>'surname', 'placeholder'=>'Apellido', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
      <!-- <label for="inputEmail4" style="padding-left: 20px; ">Apellido</label>
      <input class="form-control" id="inputEmail4" type="text" value="" name="surname"placeholder="Apellido" required style="margin-left: 20px;max-width:84%"> <span><?php echo $passwordErr;?></span> -->
    </div>
  </div>
  <div class="form-group">
    <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Dirección','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'text', 'class'=>'form-control', 'id'=>'inputAddress', 'name'=>'add', 'placeholder'=>'Dirección', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
    <!-- <label for="inputAddress" style="padding-left: 20px; ">Dirección</label>
    <input class="form-control" id="inputAddress" type="text" name="add" placeholder="Dirección" required style=" margin-left: 20px; max-width:92%"> -->
  </div>
    <div class="form-group">
      <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Ciudad','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'text', 'class'=>'form-control', 'id'=>'inputAddress', 'name'=>'city', 'placeholder'=>'Ciudad', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
    <!-- <label for="inputAddress" style="padding-left: 20px; ">Ciudad</label>
    <input class="form-control" id="inputAddress"  type="text" name="city" placeholder="Ciudad" required style=" margin-left: 20px; max-width:92%"> -->
  </div>
  <div class="form-row">
     <?php 
      $d2=array('class'=>'slabels');
      echo form_label('Esatado','state',$d2);
       ?>
        <?php 
      $d2=array('style'=> 'padding-left: 45%; float: left;');
      echo form_label('Código postal','mail',$d2);
       ?>
  <!-- <label  class="slabels"for="state">Esatado</label>
  <label for="inputEmail4" style="padding-left: 45%; float: left;">Código postal</label> -->
</div>
  <div class="form-row">
    <?php
     $options=array(
      'Escoger' => 'Escoger',
      'E2' => 'Escoger',
      'E3' => 'Escoger',
    );
     $ex=array('class'=>'form-control', 'required', 'style'=>'margin-left: 20px; max-width:50%');
    echo form_dropdown('state',$options,'Escoger',$ex);
    ?>
 <!--  <select class="form-control" name="state" required style=" margin-left: 20px; max-width:50%">
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
</select> -->
  <div class="form-group col-md-4">
     <?php 
      $data=array('type'=> 'text', 'class'=>'form-control', 'id'=>'inputAddress', 'name'=>'postal', 'placeholder'=>'postal', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
      <!-- <input  class="form-control" id="inputEmail4" ype="text" value="" name="postal" required style="margin-left: 20px;max-width:80%"> <span><?php echo $passwordErr;?></span> -->
    </div>
  </div>
 
      <div style="margin: 30px 0px 10px 20px;"class="inner">
        <?php

        $ex= array('class'=> 'signbutton','type' =>'submit');
        echo form_submit('register', 'Registrarse', $ex);
         ?>
        <!-- <button class="signbutton" type="submit" name="register">Registrarse</button> -->
        </div>
      <hr>
       <div style="margin: 30px 0px 10px 20px;float:right"class="inner">
        <?php

        $ex= array('class'=> 'signbutton','style' => ' background-color:#C0C0C0; color:black; padding:20px 30px 20px 30px ' );
        echo form_button('none', 'Cerrar', $ex);
         ?>
        <!-- <button style="background-color:#C0C0C0; color:black; padding:20px 30px 20px 30px"class="signbutton">Cerrar</button></div> -->
    </section>
    <?php echo form_close(); ?>
<!-- </form> -->
</div>

<div id="biz" class="bg">
<form name="fmessage" class="individual animate" action="signUp.php" onsubmit=" return validfoundation()" method="post" enctype="multipart/form-data" style="height: 800px">
    <section>
      <p class="form-heading" style="text-align: left;text-decoration: none; color: black">Registro Negocio o Fundacion</p>
      <hr>
  <div style="float:left;margin-right:40px;">
    <input id="roleId" name="froleId" type="hidden" value="2">
    <label  class="slabels"for="mail">Correo</label>
    <input class="s-input-field " id="mail" type="email" value="" name="fmail" placeholder="Correo" required>
  </div>

  <div style="float:left;">
    <label class="slabels" for="password">Contraseña</label>
    <input class="s-input-field " id="pass" type="password" value="" name="fpassword" placeholder="Contraseña" required>
  </div>

<div style="float:left;margin-right:40px;">
    <label  class="slabels"for="name">Nombre</label>
    <input class="s-input-field " id="fname" type="text" value="" name="fname"placeholder="Nombre" required>
  </div>

  <div style="float:left;">
    <label class="slabels" for="password">Apellido</label>
    <input class="s-input-field " id="surname" type="text" value="" name="fsurname"placeholder="Apellido" required>
  </div>
<div style="float:left;margin-right:40px;">
    <label  class="slabels"for="add">Dirección</label>
    <input class="stretched " id="add" type="text" value="" name="fadd" placeholder="Dirección" required>
  </div>
      <div style="float:left;margin-right:40px;">
    <label  class="slabels"for="city">Ciudad</label>
    <input class="stretched " id="city" type="text" value="" name="fcity" placeholder="Ciudad" required>
  </div>
      <div style="float:left;margin-right:40px;">
    <label  class="slabels"for="state">Esatado</label>
    <select id="drop" name="fstate" required>
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
        </select>
  </div>
  <div style="float:left;">
    <label class="slabels" for="postal">Código postal</label>
    <input style="width:180px"class="s-input-field " id="postal" type="text" value="" name="fpostal" required >
  </div>
  <div id="typeRadios">
    <div class="radios"><label for="one">
<input type="radio" id="one" name="ftype" value="B1" required/>
Tipo de negocio 1
</label></div>
    <div class="radios"><label for="one">
<input type="radio" id="two" name="ftype" value="B2" />
Tipo de negocio 2
</label></div>
    <div class="radios"><label for="one">
<input type="radio" id="three" name="ftype" value="B3" />
Tipo de negocio 3
</label></div>
  </div>
  <div style="margin: 30px 0px 10px 20px;"class="inner"><button class="signbutton" name="fregister">Registrarse</button></div>
      <hr>
       <div style="margin: 30px 0px 10px 20px;float:right; position: relative;bottom: 20px"class="inner"><button style="background-color:#C0C0C0; color:black; padding:20px 30px 20px 30px"class="signbutton">Cerrar</button></div>
    </section>
</form>
</div>



<div id="agent" class="bg">
  <?php $attributes = array('class' => 'individual animate', 'style' => 'height:800px','onsubmit' => 'return formValidation()'); ?>
  <?php echo form_open('Users/CreateUser',$attributes); ?>
<!-- <form name="message" class="individual animate"  onsubmit="return formValidation()" method="post" enctype="multipart/form-data"  style="height:800px"> -->
    <section>
      <p class="form-heading" style="text-align: left;text-decoration: none; color: black">Registro Individual</p>
      <hr>
       <div class="form-row">
    <div class="form-group col-md-6">
      <?php 
      $d1= array('id'=>'roleId','name'=>'roleId','type'=>'hidden','value'=>'3');
       ?>
       <?php echo form_input($d1)?>



      <!-- <input id="roleId" name="roleId" type="hidden" value="1"> -->
      
      <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Correo','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'email', 'class'=>'form-control', 'id'=>'inputEmail4', 'name'=>'mail', 'placeholder'=>'Correo', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
       <?php echo form_error('mail'); ?>
      <!-- <label for="inputEmail4" style="padding-left: 20px; ">Correo</label>
      <input type="email" class="form-control" id="inputEmail4" name="mail" placeholder="Correo" required style="margin-left: 20px;max-width:84%">  -->
      <!-- <span><?php echo $mailErr;?></span> -->
    </div>
    <div class="form-group col-md-6">
       <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Contraseña','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'password', 'class'=>'form-control', 'id'=>'inputEmail4', 'name'=>'password', 'placeholder'=>'Contraseña', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
      <!-- <label for="inputEmail4" style="padding-left: 20px; ">Contraseña</label>
      <input  class="form-control" id="inputEmail4" type="password" name="password" placeholder="Contraseña" required style="margin-left: 20px;max-width:84%"> <span><?php echo $passwordErr;?></span> -->
    </div>
  </div>
      <div class="form-row">
    <div class="form-group col-md-6">
      <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Nombre','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'text', 'class'=>'form-control', 'id'=>'inputEmail4', 'name'=>'name', 'placeholder'=>'Nombre', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
      <!-- <label for="inputEmail4" style="padding-left: 20px; ">Nombre</label>
      <input  class="form-control" id="inputEmail4" type="text" name="name"placeholder="Nombre" required style="margin-left: 20px;max-width:84%"> <span><?php echo $mailErr;?></span> -->
    </div>
    <div class="form-group col-md-6">
        <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Apellido','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'text', 'class'=>'form-control', 'id'=>'inputEmail4', 'name'=>'surname', 'placeholder'=>'Apellido', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
      <!-- <label for="inputEmail4" style="padding-left: 20px; ">Apellido</label>
      <input class="form-control" id="inputEmail4" type="text" value="" name="surname"placeholder="Apellido" required style="margin-left: 20px;max-width:84%"> <span><?php echo $passwordErr;?></span> -->
    </div>
  </div>
  <div class="form-group">
    <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Dirección','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'text', 'class'=>'form-control', 'id'=>'inputAddress', 'name'=>'add', 'placeholder'=>'Dirección', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
    <!-- <label for="inputAddress" style="padding-left: 20px; ">Dirección</label>
    <input class="form-control" id="inputAddress" type="text" name="add" placeholder="Dirección" required style=" margin-left: 20px; max-width:92%"> -->
  </div>
    <div class="form-group">
      <?php 
      $d2=array('style'=> 'padding-left:20px;');
      echo form_label('Ciudad','mail',$d2);
       ?>

       <?php 
      $data=array('type'=> 'text', 'class'=>'form-control', 'id'=>'inputAddress', 'name'=>'city', 'placeholder'=>'Ciudad', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
    <!-- <label for="inputAddress" style="padding-left: 20px; ">Ciudad</label>
    <input class="form-control" id="inputAddress"  type="text" name="city" placeholder="Ciudad" required style=" margin-left: 20px; max-width:92%"> -->
  </div>
  <div class="form-row">
     <?php 
      $d2=array('class'=>'slabels');
      echo form_label('Esatado','state',$d2);
       ?>
        <?php 
      $d2=array('style'=> 'padding-left: 45%; float: left;');
      echo form_label('Código postal','mail',$d2);
       ?>
  <!-- <label  class="slabels"for="state">Esatado</label>
  <label for="inputEmail4" style="padding-left: 45%; float: left;">Código postal</label> -->
</div>
  <div class="form-row">
    <?php
     $options=array(
      'Escoger' => 'Escoger',
      'E2' => 'Escoger',
      'E3' => 'Escoger',
    );
     $ex=array('class'=>'form-control', 'required', 'style'=>'margin-left: 20px; max-width:50%');
    echo form_dropdown('state',$options,'Escoger',$ex);
    ?>
 <!--  <select class="form-control" name="state" required style=" margin-left: 20px; max-width:50%">
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
</select> -->
  <div class="form-group col-md-4">
     <?php 
      $data=array('type'=> 'text', 'class'=>'form-control', 'id'=>'inputAddress', 'name'=>'postal', 'placeholder'=>'postal', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
       ?>
      <!-- <input  class="form-control" id="inputEmail4" ype="text" value="" name="postal" required style="margin-left: 20px;max-width:80%"> <span><?php echo $passwordErr;?></span> -->
    </div>
  </div>
 
      <div style="margin: 30px 0px 10px 20px;"class="inner">
        <?php

        $ex= array('class'=> 'signbutton','type' =>'submit');
        echo form_submit('register', 'Registrarse', $ex);
         ?>
        <!-- <button class="signbutton" type="submit" name="register">Registrarse</button> -->
        </div>
      <hr>
       <div style="margin: 30px 0px 10px 20px;float:right"class="inner">
        <?php

        $ex= array('class'=> 'signbutton','style' => ' background-color:#C0C0C0; color:black; padding:20px 30px 20px 30px ' );
        echo form_button('none', 'Cerrar', $ex);
         ?>
        <!-- <button style="background-color:#C0C0C0; color:black; padding:20px 30px 20px 30px"class="signbutton">Cerrar</button></div> -->
    </section>
    <?php echo form_close(); ?>
<!-- <form name="message" class="individual animate" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data"  style="height:800px">
    <section>
      <p class="form-heading" style="text-align: left;text-decoration: none; color: black">Registro de Agente LEAN</p>
      <hr>
       <div class="form-row">
    <div class="form-group col-md-6">
      <input id="roleId" name="roleId" type="hidden" value="3">
      <label for="inputEmail4" style="padding-left: 20px; ">Correo</label>
      <input type="email" class="form-control" id="inputEmail4" name="mail" placeholder="Correo" required style="margin-left: 20px;max-width:84%"> <span><?php echo $mailErr;?></span>
    </div>
    <div class="form-group col-md-6">
      <label for="inputEmail4" style="padding-left: 20px; ">Contraseña</label>
      <input  class="form-control" id="inputEmail4" type="password" name="password" placeholder="Contraseña" required style="margin-left: 20px;max-width:84%"> <span><?php echo $passwordErr;?></span>
    </div>
  </div>
      <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4" style="padding-left: 20px; ">Nombre</label>
      <input  class="form-control" id="inputEmail4" type="text" name="name"placeholder="Nombre" required style="margin-left: 20px;max-width:84%"> <span><?php echo $mailErr;?></span>
    </div>
    <div class="form-group col-md-6">
      <label for="inputEmail4" style="padding-left: 20px; ">Apellido</label>
      <input class="form-control" id="inputEmail4" type="text" value="" name="surname"placeholder="Apellido" required style="margin-left: 20px;max-width:84%"> <span><?php echo $passwordErr;?></span>
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress" style="padding-left: 20px; ">Dirección</label>
    <input class="form-control" id="inputAddress" type="text" name="add" placeholder="Dirección" required style=" margin-left: 20px; max-width:92%">
  </div>
    <div class="form-group">
    <label for="inputAddress" style="padding-left: 20px; ">Ciudad</label>
    <input class="form-control" id="inputAddress"  type="text" name="city" placeholder="Ciudad" required style=" margin-left: 20px; max-width:92%">
  </div>
  <div class="form-row">
  <label  class="slabels"for="state">Esatado</label>
  <label for="inputEmail4" style="padding-left: 45%; float: left;">Código postal</label>
</div>
  <div class="form-row">
  <select class="form-control" name="state" required style=" margin-left: 20px; max-width:50%">
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
</select>
  <div class="form-group col-md-4">
      <input  class="form-control" id="inputEmail4" ype="text" value="" name="postal" required style="margin-left: 20px;max-width:80%"> <span><?php echo $passwordErr;?></span>
    </div>
  </div>
 
      <div style="margin: 30px 0px 10px 20px;"class="inner"><button class="signbutton" type="submit" name="register">Registrarse</button></div>
      <hr>
       <div style="margin: 30px 0px 10px 20px;float:right"class="inner"><button style="background-color:#C0C0C0; color:black; padding:20px 30px 20px 30px"class="signbutton">Cerrar</button></div>
    </section>
</form> -->
</div>







<!-- <div id="agent" class="bg" >
<form name="message" class="individual animate" action="signUp.php" onsubmit="return formValidation()" method="post" enctype="multipart/form-data">
    <section>
      <p class="form-heading" style="text-align: left;text-decoration: none; color: black">Registro de Agente LEAN</p>
      <hr>
  <div style="float:left;margin-right:40px;">
    <input id="roleId" name="roleId" type="hidden" value="3">
    <label  class="slabels"for="mail">Correo</label>
    <input class="s-input-field " id="mail" type="email" value="" name="amail" placeholder="Correo" required>
  </div>

  <div style="float:left;">
    <label class="slabels" for="password">Contraseña</label>
    <input class="s-input-field " id="pass" type="password" value="" name="Contraseña" placeholder="apassword" required>
  </div>

<div style="float:left;margin-right:40px;">
    <label  class="slabels"for="name">Nombre</label>
    <input class="s-input-field " id="fname" type="text" value="" name="aname"placeholder="Nombre" required>
  </div>

  <div style="float:left;">
    <label class="slabels" for="password">Apellido</label>
    <input class="s-input-field " id="surname" type="text" value="" name="asurname"placeholder="Apellido" >
  </div>
<div style="float:left;margin-right:40px;">
    <label  class="slabels"for="add">Dirección</label>
    <input class="stretched " id="add" type="text" value="" name="aadd" placeholder="Dirección" >
  </div>
      <div style="float:left;margin-right:40px;">
    <label  class="slabels"for="city">Ciudad</label>
    <input class="stretched " id="city" type="text" value="" name="acity" placeholder="Ciudad" required>
  </div>
      <div style="float:left;margin-right:40px;">
    <label  class="slabels"for="state">Esatado</label>
    <select id="drop" name="astate" required>
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
        </select>
  </div>

  <div style="float:left; margin-right:40px;">
    <label class="slabels" for="postal">Código postal</label>
    <input style="width:180px"class="s-input-field " id="postal" type="text" value="" name="apostal" required>
  </div>
      <div style="margin: 30px 0px 10px 20px;"class="inner"><button class="signbutton">Registrarse</button></div>
      <hr>
       <div style="margin: 30px 0px 10px 20px;float:right"class="inner"><button style="background-color:#C0C0C0; color:black; padding:20px 30px 20px 30px"class="signbutton">Cerrar</button></div>
    </section>
</form>
</div> -->
  </main>
<footer>
    <div class="social">
        <div id="fheading"><h4 font-weight:bold"><span>LEAN EN LAS REDES SOCIALES</span></h4></div>
        <div class="icons">
      <a href="#"> 
<i class="fa fa-twitter" style="font-size:24px;color:#FFC300"></i> </a>
 <a href="#"> <i class="fa fa-facebook"  style="font-size:24px;color:#FFC300"></i></a> 
 <a href="#"> <i class="fa fa-instagram"style="font-size:24px;color:#FFC300"></i></a> 
    </div>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>

</div>
</footer>
<script>
// If user clicks anywhere outside pop-up will close

var i = document.getElementById('indi');
var j = document.getElementById('agent');
var k = document.getElementById('biz');
window.onclick = function(event) {
   if (event.target == i) {
       i.style.display = "none";
   }else if (event.target == j) {
       j.style.display = "none";
   }else if(event.target == k){
      k.style.display = "none";
   }
}
</script>
</body>
</html>