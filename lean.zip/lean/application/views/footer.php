<footer>
<div class="subscribe subscribe_theme">
<?php
$attributes= array('class'=>'subscribe__item form', 'id'=>'form' ); ?>
<?php echo form_open('Users/subscibe',$attributes) ?>
<!-- <form class="subscribe__item form" id="form" action="https://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('https://feedburner.google.com/fb/a/mailverify?uri=Leanevento', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true"> -->
<div class='register-text'><i class="fa fa-paper-plane-o"></i>    Registrese para recibir un <br/> bolitin </div>
<?php $data= array('class'=>'form__email', 'id'=>'email','style'=> 'border-bottom-left-radius: 2rem; border-top-left-radius: 2rem; border: .0001rem solid #FFC300; flex-grow: 1; max-width: 20rem; height: 1.2rem;',  'name'=>'email', 'type'=>'email', 'name'=>'email', 'placeholder'=>'Introduce tu correo electronico');
echo form_input($data);
 ?>
<!-- <input class="form__email" id="email" style=" border-bottom-left-radius: 2rem; border-top-left-radius: 2rem; border: .0001rem solid #FFC300; flex-grow: 1; max-width: 20rem; height: 1.2rem; "  name="email" type="email" name="email" placeholder="Introduce tu correo electronico" > -->
<?php
$data = array('type'=>'hidden', 'value'=>'Leanevento', 'name'=>'uri');
echo form_input($data);
?>
<?php
$data = array('type'=>'hidden', 'value'=>'en_US', 'name'=>'loc');
echo form_input($data);
?>
<?php
$data = array('type'=>'submit', 'class'=>'form__submit button button_theme_dark' ,'value'=>'Suscribir', 'id'=> 'submit', 'name'=>'loc');
echo form_submit($data);
?>
<!-- </form> -->
<?php echo form_close(); ?>
</div>
<div class="social">
<div id="fheading"><h4 font-weight:bold"><span>LEAN EN LAS REDES SOCIALES</span></h4></div>
<div class="icons">
<a href="#">
<i class="fa fa-twitter" style="font-size:24px;color:#FFC300"></i> </a>
<a href="#"> <i class="fa fa-facebook"  style="font-size:24px;color:#FFC300"></i></a>
<a href="#"> <i class="fa fa-instagram"style="font-size:24px;color:#FFC300"></i></a>
</div>
<div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
</div>

</div>
</footer>
</body>

</html>
