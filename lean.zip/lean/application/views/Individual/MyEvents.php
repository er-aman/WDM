
<main>
  <h1 style="text-align: center;">Lista de Eventos</h1>
  <div id="page">
      <table id="cart">
        <thead id="headings">
          <tr>
            <th class="photo">&nbsp</th>
            <th class="event">DETALLES DEL EVENTOS</th>
            <th class="lugar">LUGAR</th>
            <th class="hora">HORA</th>
          </tr>
        </thead>
        <tbody>
          <?php
    //        echo '<pre>';
    // print_r($events);
    // echo '</pre>';

          // while ($events) {
          //   $event_id = $events->event_id;
          //   $event_name = $events->event_name;
          //   $event_resp = $events->responsible;
          //   $event_date = $events->date;
          //   $event_time = $events->time;
          //   $event_desc = $events->description;
          //   $event_img = $events->image;
          //   echo "
          //    <tr class='eventitm'>
          //   <td><img src='imagenes/$event_img' class='thumb'></td>
          //   <td style='text-align:left;'>$event_name</td>
          //   <td>$event_resp</td>
          //   <td>$event_date</td>
          //   <td>$event_time</td>
          //   // <td><a href='HomeIndividual.php?add_event=$event_id'><button class='conbutton'>Confirmar</button></a></td>
          // </tr>
          //   ";
          // }

          ?>
          <?php foreach ($evnts as $evt): ?>
              <tr class='eventitm'>
             <td><img src='<?=base_url("imagenes/$evt->image");?>' class='thumb'></td>
             <td style='text-align:left;'> <?php echo $evt->event_name; ?></td>
             <td><?php echo $evt->date; ?></td>
             <td><?php echo $evt->time; ?></td>
            </tr>

          <?php endforeach;?>
        </tbody>
      </table>
    </div>
    <div id="welcome" class="bg">
<form name="message" class="forgotpwd animate">
    <section>
      <h3 style="text-decoration: none; text-align: center;">Bienvenido</h3>
      <hr>
      <p style="text-align: center; font-size: 1.2rem">Gracias por ser un Voluntario en nuestros evento.</p>
      <hr style="margin-top: 50px">
       <div style="margin: 30px 0px 10px 2px;float:right"class="inner"><button style="background-color:#C0C0C0; color:black; padding:10px 20px 10px 20px"class="signbutton">Close</button> </div>
    </section>
</form>
</div>
</main>