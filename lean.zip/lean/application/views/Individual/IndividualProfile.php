


<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <?=link_tag('CSS/leanevent.css'); ?>
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script>
  function validEvent(){
    var nom = document.forms['message']['name'];
    var res = document.forms['message']['surname'];
    var lug = document.forms['message']['mail'];
    var fech = document.forms['message']['phone'];
    var hora= document.forms['message']['u_name'];
    var bora= document.forms['message']['u_password'];

    if(nom.value==""){
      window.alert("Please enter name");
      nom.focus();
      return false;
    }
    if(res.value==""){
      window.alert("Please enter Surname");
      res.focus();
      return false;
    }
    if(lug.value ==""){
      window.alert("Please fill email");
      lug.focus();
      return false;
    }
    if(fech == ""){
      window.alert("Plese fill the phone");
      fech.focus();
      return false;
    }
    if(hora.value == ""){
      window.alert("Please fill user name");
      hora.focus();
      return false;
    }if(bora.value == ""){
      window.alert("Please fill password");
      bora.focus();
      return false;
    }
     if(!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.getElementById('m').value)){
        window.alert("invalid mail");
        return false;
      }
      if(!/^([a-zA-Z0-9@*#]{8,})$/.test(document.getElementById('p1').value)){
        window.alert("invalid Password");
        return false;
      }
      if(!/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/.test(document.getElementById('pn').value)){
        window.alert("invalid Phone");
        return false;
      }

    return true;
  }
</script>
</head>

<body>
<div id="wrapper">

<main>
  <div class= "container-image ">
    <img src="<?=base_url('imagenes/bannercontacto.jpg');?>"/>
    <div class="headCenter"><h1 style="margin: 0px;">PERFIL</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">INICIO</span> &nbsp; PERFIL</div>
  </div>
  <div class="info-container" style="margin-top: 100px;">
    <h3>Tu Información del Perfil</h3>
    <div class="prof"><i class="fa fa-book" style="font-size: 24px"> </i>  &nbsp; Nombres y Apellidos del Inscrito <br/><i class="fa fa-book" style="font-size: 24px"> </i>  &nbsp; Nombre de la Fundacion </br> <i class="fa fa-user" style="font-size: 24px"> </i>  &nbsp; <?php echo $details[0]->first_name; ?></div>
    <div class="prof" style="line-height: 2.5rem"><i class="fas fa-map-marker-alt"></i>  &nbsp; <?php echo $details[0]->address; ?>, <br/><?php echo $details[0]->city; ?> <?php echo $details[0]->state; ?> <?php echo $details[0]->postal_code; ?><br/> <i class="fas fa-phone"></i><?php echo $details[0]->telephone; ?></br> <i class="fa fa-paper-plane-o"></i> <?php echo $details[0]->mail;?></div>
    <div class="prof">
      <?php foreach ($details as $evt): ?>
        <img src='<?=base_url("imagenes/$evt->picture");?>'alt="Nature" class="responsive" height='200px' width="50%">
        <?php endforeach;?> <br/> </div>
  </div>
  <div id="profileForm" style=" position: relative; top:250px; height: 1100px">
    <h3>Estar en contacto</h3>
    <?php 
    $att = array(
      'name' => 'message',
      'onsubmit'=>'return validEvent()',
      'enctype'=>'multipart/form-data'
    );
    echo form_open('Individual/Update',$att) ?>
    <!-- <form name="message" action="" onsubmit="return validEvent()" method="post" enctype="multipart/form-data"> -->
    <div class="info-container" style="margin-left: 20px;">
    <div class="prof">
       <div class="form-group" style="margin-left:20px">
        <?php 
        echo form_label('Nombres','formGroupExampleInput');
        $data= array('type'=>'text','class'=>'form-control', 'id'=>'formGroupExampleInput', 'name'=>'name', 'placeholder'=>'Tu Nombre', 'value'=>'');
        echo form_input($data);
        ?>

    <!-- <label for="formGroupExampleInput">Nombres</label>
    <input type="text" class="form-control" id="formGroupExampleInput" name="name" placeholder="Tu Nombre" value=""> -->
  </div>
  <div class="form-group" style="margin-left:20px">
    <?php 
        echo form_label('Apellidos','formGroupExampleInput');
        $data= array('type'=>'text','class'=>'form-control', 'id'=>'formGroupExampleInput', 'name'=>'surname', 'placeholder'=>'Tu Apellidos ', 'value'=>'');
        echo form_input($data);
        ?>
    <!-- <label for="formGroupExampleInput2">Apellidos</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" name="surname" placeholder="Tu Apellidos " value=""> -->
  </div>
    <!-- <label  class="slabels"for="mail">Nombres </label>
    <input class="c-input-field " id="mail" type="email" value="" name="mail" placeholder="Tu Nombre"><label  class="slabels"for="mail">Apellidos</label>
    <input class="c-input-field " id="mail" type="email" value="" name="mail" placeholder="Tu Apellidos ">  --> </div>
    <div class="prof" style="line-height: 2.5rem"></div>
    <div class="prof">
      <?php foreach ($details as $evt): ?>
        <img src='<?=base_url("imagenes/$evt->picture");?>'alt="Nature" class="responsive" height='200px' width="70%">
        <?php endforeach;?> <br/> <br/>
      <?php
      $data= array('class'=>'custom-file-upload', 'style'=>'border: 1px solid #ccc;
    display: inline-block;
    padding: 6px 12px;
    cursor: pointer;
    border-radius: 3rem;
    color: white;
    background-color: #FFC300; 
    border: 0;  
    text-align: center; 
    width: 70%; 
    font-weight:bold;'); 
        echo form_label('Seleccionar Foto','file-upload',$data);?>
        <?php 
        $data= array('id'=>'file-upload', 'type'=>'file', 'style'=>'display: none;', 'name'=>'u_image');
        echo form_input($data);
        ?>
 <!--      <label for="file-upload" class="custom-file-upload" style="border: 1px solid #ccc;
    display: inline-block;
    padding: 6px 12px;
    cursor: pointer;
    border-radius: 3rem;
    color: white;
    background-color: #FFC300; 
    border: 0;  
    text-align: center; 
    width: 70%; 
    font-weight:bold;">  Seleccionar Foto
</label><input id="file-upload" type="file" style="display: none;" name="u_image" /> -->
      <!-- <input type='file' class="signbutton" title="Select" id="aa" onchange="pressed()" style=" border-radius: 3rem;color:white; padding: 1rem ;background-color: #FFC300; border: 0;  text-align: center; width: 70%; font-weight:bold; color:transparent;" value="Seleccionar Foto">
      <button class="signbutton" id="upload" style="text-align: center; width: 70%; font-weight:bold">Seleccionar Foto</button></div> -->
  </div>
  <div class="form-group" style="margin:0px 20px 0px 20px; position: relative;top: 240px">
    <?php
    echo form_label('Correo','exampleFormControlInput1');
    $data= array('type'=>'email', 'class'=>'form-control', 'id'=>'m', 'placeholder'=>'Tu correo electrónico', 'value'=>'', 'name'=>'mail');
    echo form_input($data);
    ?>
  </div>

   <div class="form-row" style="margin:0px 20px 0px 20px; position: relative;top: 300px">
    <div class="col-md-4 mb-3">
      <?php
    echo form_label('Telefono','validationCustom01');
    $data= array('type'=>'phone', 'class'=>'form-control', 'id'=>'pn', 'placeholder'=>'Telefono', 'value'=>'', 'name'=>'phone', 'required');
    echo form_input($data);
    ?>
      <div class="valid-feedback">
        Looks good!
      </div>
    </div>
    <div class="col-md-4 mb-3">
        <?php
    echo form_label('Usuario','validationCustom02');
    $data= array('type'=>'text', 'class'=>'form-control', 'id'=>'validationCustom02', 'placeholder'=>'Usuario', 'value'=>'', 'name'=>'u_name', 'required');
    echo form_input($data);
    ?>
      <!-- <label for="validationCustom02">Usuario</label>
      <input type="text" class="form-control" id="validationCustom02" name="u_name" placeholder="Usuario"required value=""> -->
    </div>
    <div class="col-md-4 mb-3">
          <?php
    echo form_label('Contraseña','validationCustom02');
    $data= array('type'=>'password', 'class'=>'form-control', 'id'=>'p1', 'placeholder'=>'Contraseña', 'value'=>'', 'name'=>'u_password', 'required');
    echo form_password($data);
    ?>
      <!-- <label for="validationCustom02">Contraseña</label>
      <input type="password" class="form-control" id="p1" name="u_password" placeholder="Contraseña" value="" required> -->
    </div>
  </div>


  <!-- <div style="float:left;margin-right:40px; position: relative;top: 240px">
    <label  class="slabels"for="add">Correo</label>

    <input class="stretched " id="add" style="width: 1060px" type="text" value="" name="add" placeholder="Tu correo electrónico">
  </div>
 -->    <!-- <div class="info-container" style="background-color: red; position: relative;top: 200px">
    <div class="prof"><label  class="slabels"for="mail">Telefono</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="Telefono"> </div>
    <div class="prof"><label  class="slabels"for="mail">Usuario</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="Usuario"> </div>
    <div class="prof"><label  class="slabels"for="mail">Contraseña</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="Contraseña"> </div>
  </div> -->
   <div class="form-group" style="float:left;margin-right:40px; position: relative;top: 300px">
    <div class="form-check">
      <?php
      $d1= array('class'=>'slabels signbutton','style'=>'padding: 3px;');
    echo form_label('Nota:','add',$d1);
    ?>
      <br>
      <?php
       $d2= array('class'=>'form-check-label','style'=>'margin-left: 10px;');
    echo form_label('Solo puede Cambiar los datos (Telefono, Contraseña y Logo)','invalidCheck',$d2);
    ?>
    </div>
  </div>
  <!-- <div style="float:left;margin-right:40px; position: relative;top: 240px">
    <label  class="slabels signbutton"for="add" style="padding: 3px;">Nota:</label>
    <br/> <p style="padding-left: 10px">Solo puede Cambiar los datos (Telefono, Contraseña y Logo)</p>
  </div> -->
  <!-- <div class="row" style=" position: relative; top: 250px;">
    <div class="col text-center">
      <button class="btn btn-default signbutton" style="border-radius: 3rem;">Centered button</button>
    </div>
  </div> --> 
  <div style=" position: relative; top: 400px; text-align: center;"class="inner">
<?php 
$data = array('class'=>'signbutton', 'style'=>'text-align: center;', 'name'=>'update','type'=>'submit', 'value'=>'Guardar Cambios');
echo form_submit($data);
?>
<!-- <button class="signbutton" style="text-align: center;" name="update">Guardar Cambios
</button> --></div> 
<?php echo form_close(); ?>
  <!-- </form> -->
  </div>
  </main>
<script>
  window.pressed = function(){
    var a = document.getElementById('aa');
    if(a.value == "")
    {
        fileLabel.innerHTML = "Choose file";
    }
    else
    {
        var theSplit = a.value.split('\\');
        fileLabel.innerHTML = theSplit[theSplit.length-1];
    }
};
</script>
</body>

</html>