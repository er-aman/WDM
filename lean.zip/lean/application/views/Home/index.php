<!-- <!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="icon" href="<?= base_url('imagenes/favicon.ico'); ?>" type="image/gif">
  <?=link_tag('CSS/leanevent.css'); ?>
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src="<?= base_url('imagenes/logo-blanco.png'); ?>" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="home.php" id="active">Inicio</a>
        <a href="AboutUs.php" >Quienes Somos</a>
        <a href="http://amanarora.uta.cloud/blog/">Blog</a>
        <a href="signUp.php">Registrate</a>
        <a href="Contact.php">Contacto</a>
        <a href="Login.php">Iniciar Sesion</a>
        <a href="BuyFromUs.php">Comprar Boletos</a></li>

      </li>
    </ul>
  </nav>
</header> -->

<main>
  <div class= "container-image ">
    <img src="<?= base_url('imagenes/bannerlean2.jpg'); ?>"/>
    <img src="<?= base_url('imagenes/logo-blanco.png'); ?>" style="width: 20%;height: auto; align-content: left;position: absolute;
  top: 50px;
  left: 60%;" />
  </div>  

  <div id="hacemos">
    <h2>¿QUÉ HACEMOS?</h2>
    <p>La asociación civil LEAN fue creada con el objetivo de ayudar, a través de acciones concretas, a nuestros conciudadanos en Venezuela ante la grave escasez de medicinas e insumos médicos en que se encuentra el país. Nuestra misión consiste en recolectar ayuda médico sanitaria en delegaciones en España y, a través de agentes de transporte, llevarlos a Venezuela para que otras asociaciones se encarguen de su distribución. De esta manera aportamos nuestro granito de arena ayudando a llevar asistencia humanitaria a Venezuela. Somos una asociación sin fines de lucro, dedicada a la defensa de los Derechos Humanos. </p>
  </div>
  <div id="container">
 <div class="box1">
   <h4><strong>478</strong><br>VOLUNTARIOS</h4>
 </div>
 <div class="box2">
   <h4>60.000 <br> PERSONAS BENEFICIADAS</h4>
 </div>
 <div class="box3">
   <h4>45<br> ALIADOS</h4>
 </div>
 <span class="stretch"></span>
</div>
<div id="slogan">
  <img src="<?= base_url('imagenes/bannerabout.jpg'); ?>" />
  <div class="centered">"La injusticia, en cualquier parte,es una amenaza a la justicia en todas partes."</div>
  <div class="martin">Martin Luther King</div>
</div>
<div id="Aliados">
  <h2>ALIADOS</h2>
</div>
<div id="organizations">
  <div class="box4">
    <img src="<?= base_url('imagenes/logo1.PNG'); ?>" />
 </div>
 <div class="box5">
   <img src="<?= base_url('imagenes/logo2.PNG'); ?>" /> </div>
 <div class="box6">
   <img src="<?= base_url('imagenes/logo3.PNG'); ?>" />
 </div>
 <div class="box7">
   <img src="<?= base_url('imagenes/logo4.PNG'); ?>" />
 </div>
 <span class="stretch"></span>
</div>
</main>
<!-- <footer>
 <div class="subscribe subscribe_theme">
      <form class="subscribe__item form" id="form" action="https://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('https://feedburner.google.com/fb/a/mailverify?uri=Leanevento', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">
        <div class='register-text'><i class="fa fa-paper-plane-o"></i>    Registrese para recibir un <br/> bolitin </div>
        <input class="form__email" id="email" style=" border-bottom-left-radius: 2rem; border-top-left-radius: 2rem; border: .0001rem solid #FFC300; flex-grow: 1; max-width: 20rem; height: 1.2rem; "  name="email" type="email" name="email" placeholder="Introduce tu correo electronico" >
        <input type="hidden" value="Leanevento" name="uri"/><input type="hidden" name="loc" value="en_US"/>
        <input class="form__submit button button_theme_dark" id="submit" type="submit" value="Suscribir">
      </form>
    </div>
    <div class="social">
        <div id="fheading"><h4 font-weight:bold"><span>LEAN EN LAS REDES SOCIALES</span></h4></div>
        <div class="icons">
      <a href="#"> 
<i class="fa fa-twitter" style="font-size:24px;color:#FFC300"></i> </a>
 <a href="#"> <i class="fa fa-facebook"  style="font-size:24px;color:#FFC300"></i></a> 
 <a href="#"> <i class="fa fa-instagram"style="font-size:24px;color:#FFC300"></i></a> 
    </div>
    <div id="bottom"><p><small>Copyright @2019 All rights reserved | This web is made with <i class="fa fa-heart-o"></i> by <span style="color: #FFC300">DiazApps</span></small></p></div>
    </div>

</div>
</footer>
</body>

</html> -->