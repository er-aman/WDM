
<?php
// if(isset($_GET['event_id'])){
//   $_SESSION['event_id'] = $_GET['event_id'];
//   $evt_id = $_GET['event_id'];
//   $get_event = "select * from event where event_id= '$evt_id'";
//   $run_event = mysqli_query($con, $get_event);
//   $row_event = mysqli_fetch_array($run_event);
//   $event_name = $row_event['event_name'];
//   $responsible = $row_event['responsible'];
//   $date = $row_event['date'];
//   $time = $row_event['time'];
//   $ticket_value = $row_event['ticket_value'];
//   $description = $row_event['description'];
//   $image = $row_event['image'];
// }

// $mailErr=$phndErr=$nameErr=$surnameErr=$addErr=$cityErr=$stateErr=$postalErr=$test="";
// $mail=$password=$name=$surname=$add=$city=$state=$postal="" ;
// if($_SERVER["REQUEST_METHOD"] == "POST"){
//   if(empty($_POST["mail"])){
//     $mailErr = "Mail id is required.";
//   }else{
//     $mail .=test_input($_POST['mail']);

//     if(!filter_var($mail, FILTER_VALIDATE_EMAIL)){
//       $mailErr = "Invalid email format.";
//     }
//   }
//   if(empty($_POST['password'])){
//     $passwordErr="Password is required";
//   }else{
//     $password .= test_input($_POST['password']);
//   }
//   if(empty($_POST['name'])){
//     $nameErr ="Name is required";
//   }else{
//     $name .= test_input($_POST['name']);
//   }

//   if(empty($_POST['surname'])){
//     $surnameErr = "Surname is required";
//   }else{
//     $surname .= test_input($_POST['surname']);
//   }

//   if(empty($_POST['add'])){
//     $addErr = "Address is required";
//   }else{
//     $add .= test_input($_POST['add']);
//   }
//    if(empty($_POST['city'])){
//     $cityErr = "City is required";
//   }else{
//     $city .= test_input($_POST['city']);
//   }
//    if(empty($_POST['postal'])){
//     $postalErr = "Postal code is required";
//   }else{
//     $postal .= test_input($_POST['postal']);
//   }
//   if(empty($_POST['test'])){
//     $postalErr = "Postal code is required";
//   }else{
//     $test .= test_input($_POST['test']);
//   }
//    if(empty($_POST['state'])){
//     $stateErr = "State is required";
//   }else{
//     $state .= test_input($_POST['state']);
//   }

// }


// if(isset($_POST['register'])){
// $event_id= $_SESSION['event_id'];
// $x= $_SESSION['items'];   
//   $insert_user = "insert into orders(name,surname,address,phone,city,state,postal,quant,email,event_id) values ('$name','$surname','$add','$password','$city','$state','$postal','$test','$mail','$event_id')";
// $reg_user = mysqli_query($con,$insert_user);

// if($reg_user){
//   echo "<script>alert('The order has beeen placed')</script>";
//     echo "<script>window.open('BuyFromUs.php','_self')</script>";
// }
// }

// function test_input($data){
//   $data = trim($data);
//   $data = stripcslashes($data);
//   $data = htmlspecialchars($data);
//   return $data;
// }
?>
<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <?=link_tag('CSS/leanevent.css'); ?>
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body>
<div id="wrapper">
<main>
  <div class= "container-image ">
    <img src="<?= base_url('imagenes/bannercboleto.jpg'); ?>"/>
    <div class="headCenter"><h1 style="margin: 0px;">COMPRAR BOLETOS</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">INICIO</span> &nbsp; COMPRAR BOLETOS</div>
  </div>
  <div id="details-container">

      <div class="detail-first-content">

      <div class="detailContent details-img">
        <img src="<?=base_url('imagenes/$evnt[0]->image')?>" alt="Nature" class="responsive" width="100%" height="auto">
      </div>

      <div class="detailContent">
      <p><b>"<?php echo $evnt[0]->event_name; ?>"</b></p>
          <p>
              <span class="detail-left-dolor">$ <?php echo $evnt[0]->ticket_value; ?></span>
              <span class="detail-ratings-ryt">
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i>
                  <i class="fa fa-star"></i> (74 Ratings)
              </span>
          </p>
            <p id="aboutData"><?php echo $evnt[0]->description; ?></p>
          <p>Numero de Entradas</p>
             <div class="form-row">
               <input type="Button" id='SubButton' value="-" style="margin-right: 20px" />
              <input type="text" name="TextBox" id="TextBox" form="message" value="1" style="width:20px;text-align:center; border: 0" />
              <input type="Button" id='AddButton' value="+" style="margin-left: 20px"/>
             </div>
         
          <button class="btn detail-btn" onclick= "document.getElementById('indi').style.display='block'"><i class="fa fa-cart-plus"></i>  Comprar</button>
      </div>
      </div>
      <div id="indi" class="bg">
<form id="message" class="individual animate" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" onsubmit="return formValidation()" method="post" enctype="multipart/form-data"  style="height:780px">
  <?php
  $data= array(
'id'=>'message', 'class'=>'individual animate', 'onsubmit'=>'return formValidation()', 'method'=>'post', 'enctype'=>'multipart/form-data' , 'style'=>'height:780px'

  );
  echo form_open('Home/Order');
   ?>
    <section>
      <p class="form-heading" style="text-align: left;text-decoration: none; color: black">Provide Details</p>
      <hr>
      <label for="inputEmail4" style="padding-left: 20px; ">Entradas</label>
      <input id="test" name="test" visibility="hidden" value="1" style="margin-left: 20px;"></input>
      <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4" style="padding-left: 20px; ">Nombre</label>
      <input  class="form-control" id="inputEmail4" type="text" name="name"placeholder="Nombre" required style="margin-left: 20px;max-width:84%"> <span></span>
    </div>
    <div class="form-group col-md-6">
      <label for="inputEmail4" style="padding-left: 20px; ">Apellido</label>
      <input class="form-control" id="inputEmail4" type="text" value="" name="surname"placeholder="Apellido" required style="margin-left: 20px;max-width:84%"> <span></span>
    </div>
  </div>
      <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4" style="padding-left: 20px; ">Correo</label>
      <input type="email" class="form-control" id="inputEmail4" name="mail" placeholder="Correo" required style="margin-left: 20px;max-width:84%"> <span></span>
    </div>
    <div class="form-group col-md-6">
      <label for="inputEmail4" style="padding-left: 20px; ">Telephono</label>
      <input  class="form-control" id="inputEmail4" type="phone" name="password" placeholder="Telephono" required style="margin-left: 20px;max-width:84%"> <span></span>
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress" style="padding-left: 20px; ">Dirección</label>
    <input class="form-control" id="inputAddress" type="text" name="add" placeholder="Dirección" required style=" margin-left: 20px; max-width:92%">
  </div>
    <div class="form-group">
    <label for="inputAddress" style="padding-left: 20px; ">Ciudad</label>
    <input class="form-control" id="inputAddress"  type="text" name="city" placeholder="Ciudad" required style=" margin-left: 20px; max-width:92%">
  </div>
  <div class="form-row">
  <label  class="slabels"for="state">Esatado</label>
  <label for="inputEmail4" style="padding-left: 45%; float: left;">Código postal</label>
</div>
  <div class="form-row">
  <select class="form-control" name="state" required style=" margin-left: 20px; max-width:50%">
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
      <option value="Escoger">Escoger</option>
</select>
  <div class="form-group col-md-4">
      <input  class="form-control" id="inputEmail4" ype="text" value="" name="postal" required style="margin-left: 20px;max-width:80%"> <span></span>
    </div>
  </div>
 
      <div style="margin: 30px 0px 10px 20px;"class="inner"><button class="signbutton" type="submit" name="register">Confirm</button></div>
      <hr>
    </section>
<?php echo form_close();?>
</div>
    <div class="detailContent1">
        <div class="tab">
            <button class="tablinks" onclick="openDetails(event, 'description')" id="defaultOpen">DESCRIPCION</button>
            <button class="tablinks" onclick="openDetails(event, 'managers')">ENCARGADOS</button>
            <button class="tablinks" onclick="openDetails(event, 'sponsers')">PATROCINANTES</button>
        </div>

        <div id="description" class="tabcontent">
            <p id="aboutData"><?php echo $evnt[0]->description; ?></p>
        </div>

        <div id="managers" class="tabcontent">
            <p id="aboutData"><?php echo $evnt[0]->responsible; ?></p>
        </div>

        <div id="sponsers" class="tabcontent">
            <p id="aboutData">LEAN es una asociación civil sin fines de lucro conformada por gente con gran sensibilidad social,
                dedicada a la defensa de los derechos humanos y la consecución de ayuda humanitaria, favoreciendo directamente
                o a través de otras asociaciones o agrupaciones provinciales a venezolanos residentes en España y a quienes viven
                en Venezuela.</p>
        </div>

    </div>
  </div>
  </main>
</div>
<script>
    function openDetails(evt, tabs) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(tabs).style.display = "block";
        evt.currentTarget.className += " active";
    }

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();
</script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script>
  $(document).ready(function(){
       //var counter = $('#TextBox').val();
       $('#AddButton').click( function() {
           var counter = $('#TextBox').val();
           counter++ ;
           $('#TextBox').val(counter);
           document.getElementById('test').value = counter;
   });
    $('#SubButton').click( function() {
           var counter = $('#TextBox').val();
           if(counter !=1){
           counter-- ;
           }
           $('#TextBox').val(counter);
           document.getElementById('test').value = counter;
   });
});
</script>
<script>
// If user clicks anywhere outside pop-up will close

var i = document.getElementById('indi');
window.onclick = function(event) {
   if (event.target == i) {
       i.style.display = "none";
   }
}
</script>
</body>

</html>