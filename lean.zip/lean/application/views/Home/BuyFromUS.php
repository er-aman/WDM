<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">

  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <?=link_tag('CSS/leanevent.css'); ?>
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>

<body>
<div id="wrapper">
<header id="header">
<!--   <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="home.php" >Inicio</a>
        <a href="AboutUs.php" >Quienes Somos</a>
        <a href="http://amanarora.uta.cloud/blog/">Blog</a>
        <a href="signUp.php">Registrate</a>
        <a href="Contact.php">Contacto</a>
        <a href="Login.php">Iniciar Sesion</a>
        <a href="BuyFromUs.php" id="active">Comprar Boletos</a></li>

      </li>
    </ul>
  </nav> -->
</header>

<main>
  <div class= "container-image ">
    <img src="<?=base_url('imagenes/bannercboleto.jpg')?>"/>
    <div class="headCenter"><h1 style="margin: 0px;">COMPRAR BOLETOS</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">INICIO</span> &nbsp; COMPRAR BOLETOS</div>
  </div>
  <div id="events">
     <h2>NUESTROS EVENTOS</h2>
     <p> Tu asistencia es importante para nosotros visitanos en los eventos qu estamos realizando.</p>
  </div>
  <div id="content" class="container"><!-- container Starts -->

<div class="row" style="position: relative;top: 156px;"><!-- row Starts -->

    <?php
//     $get_events = "select * from event order by 1 DESC"; 
//     $run_events = mysqli_query($con,$get_events);
//     while ($row_events = mysqli_fetch_array($run_events)) {
//       $event_id =$row_events['event_id'];
//       $event_nm =$row_events['event_name'];
//       $event_price = $row_events['ticket_value'];
//       $event_imaeg = $row_events['image'];
//       echo "
//       <div class='col-xs-6 col-sm-3'>

// <div class='product' >

// <a href='DetailPage.php?event_id=$event_id' >

// <img src='imagenes/$event_imaeg' class='img-responsive' >

// </a>

// <div class='text' >

// <h3><a href='DetailPage.php?event_id=$event_id' >$event_nm</a></h3>

// <p class='price' style='color:#FFC300'>$$event_price</p>

// </div>


// </div>

// </div>
//       ";
//     }
    ?>
<?php foreach ($buy as $evt): ?>
  <div class='col-xs-6 col-sm-3'>

<div class='product' >

<a href= '<?=base_url("index.php/Home/Pro/{$evt->event_id}")?>' >

<img src='<?=base_url("imagenes/$evt->image");?>'  class='img-responsive' >

</a>

<div class='text' >

<h3><a href='<?=base_url("index.php/Home/Pro/{$evt->event_id}")?>'> <?php echo $evt->event_name; ?> </a></h3>

<p class='price' style='color:#FFC300'>$<?php echo $evt->ticket_value; ?></p>

</div>


</div>

</div>

          <?php endforeach;?>
</div><!-- row Ends -->

</div><!-- container Ends -->
  </div>  
  </main>
</body>

</html>