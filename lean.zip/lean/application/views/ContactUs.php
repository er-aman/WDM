<!-- <?php if($this->session->flashdata('errors')): ?> 
 <?php echo $this->session->flashdata('errors'); ?>
<?php endif; ?> -->
<!DOCTYPE html>

<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
  <title>LEANEVENTO</title>
  <?=link_tag('CSS/leanevent.css'); ?>
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script>
  function validEvent(){
    var nom = document.forms['message']['name'];
    var res = document.forms['message']['surname'];
    var lug = document.forms['message']['email'];
    var fech = document.forms['message']['topic'];
    var hora= document.forms['message']['message'];

    if(nom.value==""){
      window.alert("Please enter your Nombre");
      nom.focus();
      return false;
    }
    if(res.value==""){
      window.alert("Please enter Surname");
      res.focus();
      return false;
    }
    if(lug.value ==""){
      window.alert("Please fill email");
      lug.focus();
      return false;
    }
    if(fech == ""){
      window.alert("Plese fill the topic");
      fech.focus();
      return false;
    }
    if(hora.value == ""){
      window.alert("Please fill Message");
      hora.focus();
      return false;
    }
     if(!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.getElementById('m').value)){
        window.alert("invalid mail");
        return false;
      }
    return true;
  }
</script>
</head>

<body>
<div id="wrapper">
<header id="header">
</header>

<main>
  <div class= "container-image ">
    <img src="<?= base_url('imagenes/bannercontacto.jpg'); ?>"/>
    <div class="headCenter"><h1 style="margin: 0px;">CONTACTO</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">INICIO</span> &nbsp; CONTACTO</div>
  </div>
  <div id="info-container">
    <h3>Información del contacto</h3>
    <div class="info"><i class="fas fa-map-marker-alt"> </i>  &nbsp; 198 West 21st street, <br/>Suite 721 New York NY 10016</div>
    <div class="info"><i class="fas fa-phone"></i> +1235 2355 98</div>
    <div class="info"><i class="fa fa-paper-plane-o"></i> info@diazapps.com </div>
    <div class="info"><i class="fas fa-globe"></i> diazapps.com </div>
  </div>
  <div id="info-container">
    <h3>LEAN en las redes sociales</h3>
    <div class="info media"><img src="<?= base_url('imagenes/facebook.png'); ?>" height="40" width="40"/> <br/> <span style="color: #FFC300;">LEAN Ayuda Humanitaria</span></div>
    <div class="info media"><img src="<?= base_url('imagenes/twitter.png'); ?>"height="40" width="40"/><br/> <span style="color: #FFC300;">@LeanEmergente</span></div>
    <div class="info media"><img src="<?= base_url('imagenes/instagram.png'); ?>" height="40" width="40"/><br/> <span style="color: #FFC300;">@LeanAyudaHumanitaria</span></div>
    <div class="info media"><img src="<?= base_url('imagenes/correo.png'); ?>" height="40" width="40"/><br/> <span style="color: #FFC300;">lean emergente@gmail.com</span></div>
  </div>
  <div id="contactForm">
    <h3>Estar en contacto</h3>
    <?php 
    $attributes = array('name'=>'message','onsubmit'=>'return validEvent()');
   echo form_open('Home/ContactUs',$attributes); ?>
    <!-- <form name="message" action="Contact.php" onsubmit="return validEvent()" method="post"> -->
       <div class="form-row">
    <div class="form-group col-md-6">
      <?php
      $data = array( 'style'=>'padding-left: 20px;');
      echo form_label('Nombre','inputEmail4',$data);
      ?>
      <?php
      $data = array('type'=>'text', 'class'=>'form-control', 'id'=>'inputEmail4', 'name'=>'name', 'value'=> '', 'placeholder'=>'Tu Nombre', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
      ?> <?php echo form_error('name'); ?>
      <!-- <label for="inputEmail4" style="padding-left: 20px; ">Nombre</label>
      <input type="text" class="form-control" id="inputEmail4" name="name" value= "" placeholder="Tu Nombre" required style="margin-left: 20px;max-width:84%"> -->
      <!-- <span style="color: #FF0000"> <?php echo $fErr;?></span> -->
    </div>
    <div class="form-group col-md-6">
       <?php
      $data = array( 'style'=>'padding-left: 20px;');
      echo form_label('Apellido','inputPassword4',$data);
      ?>
      <?php
      $data = array('type'=>'text', 'class'=>'form-control', 'id'=>'inputPassword4', 'name'=>'surname', 'value'=> '', 'placeholder'=>'Tu Apellido', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
      ?> <?php echo form_error('surname'); ?>
      <!-- <label for="inputPassword4" style="padding-left: 20px;">Apellido</label>
      <input type="text" class="form-control" id="inputPassword4" name="surname" value= "" placeholder="Tu Apellido" required style=" margin-left: 20px; max-width:84%"> -->
      <!-- <span style="color: #FF0000"> <?php echo $lErr;?></span> -->
    </div>
  </div>
   <div class="form-group">
     <?php
      $data = array( 'style'=>'padding-left: 20px;');
      echo form_label('Correo','inputPassword4',$data);
      ?>
      <?php
      $data = array('type'=>'email', 'class'=>'form-control', 'id'=>'m', 'name'=>'email', 'value'=> '', 'placeholder'=>'1234 Main St', 'required', 'style'=>'margin-left: 20px;max-width:84%');
      echo form_input($data);
      ?> <?php echo form_error('email'); ?>
   <!--  <label for="inputAddress" style="padding-left: 20px; ">Correo</label>
    <input type="text" class="form-control" id="m" type="email" value="" name="email" placeholder="Tu correo electrónico
" required placeholder="1234 Main St" style=" margin-left: 20px; max-width:92%"> -->
<!-- <span style="color: #FF0000"> <?php echo $emailErr;?></span> -->
  </div>
  <div class="form-group">
    <?php
      $data = array( 'style'=>'padding-left: 20px;');
      echo form_label('Tema','inputAddress',$data);
      ?>
      <?php
      $data = array('type'=>'text', 'class'=>'form-control', 'id'=>'inputAddress', 'name'=>'topic', 'value'=> '', 'placeholder'=>'Su asunto de este mensaje.', 'required', 'style'=>'margin-left: 20px; max-width:92%');
      echo form_input($data);
      ?> <?php echo form_error('topic'); ?>
    <!-- <label for="inputAddress" style="padding-left: 20px; ">Tema</label>
    <input type="text" class="form-control" id="inputAddress" type="text" value="" name="topic" placeholder="
Su asunto de este mensaje." required placeholder="1234 Main St" style=" margin-left: 20px; max-width:92%"> -->
<!-- <span style="color: #FF0000"> <?php echo $topicErr;?></span> -->
  </div>
   <div class="form-group">
    <?php
      $data = array( 'style'=>'padding-left: 20px;');
      echo form_label('Mensaje','exampleFormControlTextarea1',$data);
      ?>
      <?php
      $data = array('type'=>'text', 'class'=>'form-control', 'id'=>'exampleFormControlTextarea1', 'name'=>'message', 'value'=> '', 'placeholder'=>'Di algo sobre nosotros', 'required', 'style'=>'margin-left: 20px; max-width:92%');
      echo form_textarea($data);
      ?> <?php echo form_error('message'); ?>
    <!-- <label for="exampleFormControlTextarea1" style="padding-left: 20px;">Mensaje</label> -->
    <!-- <textarea class="form-control" id="exampleFormControlTextarea1" rows="6" type="text" name="message" placeholder="Di algo sobre nosotros" value= "" required style=" margin-left: 20px; max-width:92%"></textarea> -->
    <!-- <span style="color: #FF0000"> <?php echo $messageErr;?></span> -->
  </div>
  <div style=" position: relative; left: 50%;"class="inner">
<?php
$data = array('class'=>'signbutton', 'style'=>'text-align: center;', 'type'=>'submit', 'name'=>'submit', 'value'=>'Enviar mensaje');
echo form_submit($data);
 ?> <?php echo form_error('email'); ?>
    <!-- <button class="signbutton" style="text-align: center;" type="submit" name="submit">Enviar mensaje
</button> --></div>
  <?php echo form_close(); ?>
  </div>
  </main>