<!DOCTYPE html>

<html>

<head>
  <title>LEANEVENTO</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <?=link_tag('CSS/leanevent.css');?>
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<div id="wrapper">
<header id="header">
  <nav id="nav-bar">
    <img src=" <?=base_url('imagenes/logo-blanco.png'); ?>" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="<?= base_url('index.php/Agent/AgentHome');?>">Inicio</a>
        <a href="<?= base_url('index.php/Agent/AgentListIndividual')?>">Lista de Voluntarios</a>
        <a href="<?= base_url('index.php/Agent/AgentListBusiness')?>">Lista de Fundaciones</a>
        <a href="<?= base_url('index.php/Agent/Eventos');?>">Eventos</a>
        <a href="<?= base_url('index.php/Agent/AgentProfile');?>">Agente</a>
        <a href="<?= base_url('index.php/Agent/Logout');?>">Logout</a>

      </li>
    </ul>
  </nav>
</header>