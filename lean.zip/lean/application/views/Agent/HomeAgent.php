<main>
  <div class= "container-image ">
    <img src="<?= base_url('imagenes/bannerlean1.jpg'); ?>"/>
    <img src="<?= base_url('imagenes/logo-blanco.png'); ?>" style="width: 200px;height: 200px; align-content: left;position: absolute;
  top: 50px;
  left: 60%;" />
  </div> 
</main>
</body>
</html>