<header id="header">
 <!--  <nav id="nav-bar">
    <img src="imagenes\logo-blanco.png" alt="Lean logo" class="hidden-xs" />
    <div id="logoName">
      <h3>LEANEVENTO</h3>
    </div>
    <ul>
      <li>
        <a href="HomeAgentLean.php">Inicio</a>
        <a href="AgentListIndividual.php">Lista de Voluntarios</a>
        <a href="AgentListBusiness.php">Lista de Fundaciones</a>
        <a href="" id="active">Eventos</a>
        <a href="AgentProfile.php">Agente</a>


      </li>
    </ul>
  </nav> -->
</header>
<main>
  <h1 style="text-align: center;">Lista de Eventos</h1>
  <div id="agregar">
    <div class="inner" style="margin-right: 30px; float:right;"><button id="addEvent" class="signbutton" style="background-color: #32CD32;">Agregar</button></div>
  </div>
  <div id="page">
      <table id="cart">
        <thead id="headings">
          <tr>
            <th class="photo">&nbsp</th>
            <th class="event">DETALLES DEL EVENTOS</th>
            <th class="lugar">LUGAR</th>
            <th class="fecha">FECHA</th>
            <th class="hora">MODIFICIAR</th>
            <th class="asist">ELIMINAR</th>
          </tr>
        </thead>
        <tbody>
             <?php
          //    $user_id = $_SESSION['u_id'];
          // $get_events = "select * from event where agent_id='$user_id' order by 1 DESC";
          // $run_query = mysqli_query($con, $get_events);
          // while ($row_events = mysqli_fetch_array($run_query)) {
          //   $event_id = $row_events['event_id'];
          //   $event_name = $row_events['event_name'];
          //   $event_resp = $row_events['responsible'];
          //   $event_date = $row_events['date'];
          //   $event_time = $row_events['time'];
          //   $event_desc = $row_events['description'];
          //   $event_img = $row_events['image'];
          //   echo "
          //    <tr class='eventitm'>
          //   <td><img src='imagenes/$event_img' class='thumb'></td>
          //   <td style='text-align:left;'>$event_name</td>
          //   <td>$event_desc</td>
          //   <td>$event_date</td>
          //   <td><a href='edit_event.php?edit_event=$event_id'<i class='fa fa-edit conbutton' style='font-size: 24px'></i></a></td>
          //   <td><a href='AgentListEvents.php?delete_event=$event_id'<i class='fa fa-trash conbutton' style='font-size: 24px; background-color:#B22222'></i></a></td>

          // </tr>
          //   ";
          // }

          ?>
          <?php foreach ($evnt as $evt): ?>
              <tr class='eventitm'>
             <td><img src='<?=base_url("imagenes/$evt->image");?>' class='thumb'></td>
             <td style='text-align:left;'> <?php echo $evt->event_name; ?></td>
             <td><?php echo $evt->description; ?></td>
             <td><?php echo $evt->date; ?></td>
             <td><a href= '<?=base_url("index.php/Agent/Modify/{$evt->event_id}")?>'<i class='fa fa-edit conbutton' style='font-size: 24px'></i></a></td>
             <td><a href='<?=base_url("index.php/Agent/Delete/{$evt->event_id}")?>'<i class='fa fa-trash conbutton' style='font-size: 24px; background-color:#B22222'></i></a></td>
            </tr>

          <?php endforeach;?>



          <!-- <tr class="eventitm">
            <td><img src="imagenes\minibaner1.jpg" class="thumb"></td>
            <td style="text-align:left;">Nombre del Evento y sus detalles</td>
            <td>Direccion del lugar </td>
            <td>14/01/2019</td>
            <td><button class="conbutton"><i class="fa fa-edit" style="font-size: 24px"></i></button></td>
            <td><button class="conbutton" style="background-color:#B22222 "><i class="fa fa-trash" style="font-size: 24px"></i></button></td>
          </tr>
          <tr class="eventitm">
            <td><img src="imagenes\minibaner2.jpg" class="thumb"></td>
            <td style="text-align: left">Nombre del Evento y sus detalles</td>
            <td>Design Bundle Package</td>
            <td>14/01/2019</td>
            <td><button class="conbutton"><i class="fa fa-edit" style="font-size: 24px"></i></button></td>
            <td><button class="conbutton" style="background-color:#B22222 "><i class="fa fa-trash" style="font-size: 24px"></i></button></td>
          </tr>
          <tr class="eventitm">
            <td><img src="imagenes\minibaner3.jpg" class="thumb"></td>
            <td style="text-align: left">Nombre del Evento y sus detalles</td>
            <td>Design Bundle Package</td>
            <td>14/01/2019</td>
            <td><button class="conbutton"><i class="fa fa-edit" style="font-size: 24px"></i></button></td>
            <td><button class="conbutton" style="background-color:#B22222 "><i class="fa fa-trash" style="font-size: 24px"></i></button></td>
          </tr> -->
          
        </tbody>
      </table>
    </div>
<div id="pages">
      <div class="pn"><<</div>
      <div class="pn" style="background-color: #FFC300">1</div>
      <div class="pn">2</div>
      <div class="pn">3</div>
      <div class="pn">4</div>
      <div class="pn">>></div>
    </div>
    <script type="text/javascript">
    document.getElementById("addEvent").onclick = function () {
        location.href = "<?=base_url('index.php/Agent/AddEv') ?>";
    };
</script>
</main>