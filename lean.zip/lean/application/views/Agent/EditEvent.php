
<!DOCTYPE html>

<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
  <title>LEANEVENTO</title>
  
  <link rel="stylesheet" type="text/css" href="CSS\leanevent.css">
  <?=link_tag('CSS\leanevent.css');?>
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <link rel="icon" href="imagenes/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script>
  function validEvent(){
    var nom = document.forms['message']['name'];
    var res = document.forms['message']['surname'];
    var lug = document.forms['message']['mail'];
    var fech = document.forms['message']['phone'];
    var hora= document.forms['message']['u_name'];
    var bora= document.forms['message']['u_password'];

    if(nom.value==""){
      window.alert("Please enter your Nombre");
      nom.focus();
      return false;
    }
    if(res.value==""){
      window.alert("Please enter the person Responsable");
      res.focus();
      return false;
    }
    if(lug.value ==""){
      window.alert("Please fill Lugar");
      lug.focus();
      return false;
    }
    if(fech == ""){
      window.alert("Plese fill the Fecha");
      fech.focus();
      return false;
    }
    if(hora.value == ""){
      window.alert("Please fill Hora");
      hora.focus();
      return false;
    }
      if(bora.value == ""){
      window.alert("Please fill Price");
      hora.focus();
      return false;
    }
     if(!/^\d{2}\/\d{2}\/\d{4}$/.test(document.getElementById('d').value)){
        window.alert("invalid date");
        return false;
      }
       if(!/^(0?[1-9]|1[012]):[0-5][0-9]$/.test(document.getElementById('h').value)){
        window.alert("invalid time");
        return false;
      }
    return true;
  }
</script>
</head>
<body>
<div id="wrapper">
<header id="header">
</header>

<main>
  <div class= "container-image ">
    <img src="<?= base_url('imagenes/bannerregistro.jpg');?>"/>
    <div class="headCenter"><h1 style="margin: 0px;">REGISTRO DE EVENTO</h1></div>
    <div class="optionsCent"><span style="color: #FFC300">EVENTOS</span> &nbsp; REGISTRO</div>
  </div>
    <div id="profileForm" style="height: 1000px">
    <h3>Registro de Evento</h3>
    <!-- <form name="message" action="" method="post" onsubmit="return validEvent()" enctype="multipart/form-data"> -->
      <?php

      $att= array('name'=>'message','onsubmit'=>'return validEvent();','enctype'=>'multipart/form-data');
      echo form_open_multipart('Agent/UpEvt',$att);
       ?>
    <div class="info-container" style="margin-left: 20px;">
    <div class="prof">
       <div class="form-group" style="margin-left:20px">
    <label for="formGroupExampleInput">Nombres</label>
    <input type="hidden" name="event_id"  value = "<?php echo $evnt[0]->event_id; ?>"/>
    <input type="text" class="form-control" id="formGroupExampleInput" name="name" placeholder="Nombre del Evento"  value = "<?php echo $evnt[0]->event_name; ?>"required />
    <?php echo form_error('name'); ?>
  </div>
  <div class="form-group" style="margin-left:20px">
    <label for="formGroupExampleInput2">Responsable</label>
    <input type="text" class="form-control" id="formGroupExampleInput2" name="surname" placeholder="Nombre del Responsable" value = "<?php echo $evnt[0]->responsible; ?>" > <?php echo form_error('surname'); ?>
  </div>
    <!-- <label  class="slabels"for="mail">Nombres </label>
    <input class="c-input-field " id="mail" type="email" value="" name="mail" placeholder="Tu Nombre"><label  class="slabels"for="mail">Apellidos</label>
    <input class="c-input-field " id="mail" type="email" value="" name="mail" placeholder="Tu Apellidos ">  --> </div>
    <div class="prof" style="line-height: 2.5rem"></div>
    <div class="prof"><img src="<?=base_url('imagenes/$evnt[0]->image')?>" height='200px' width="70%"/> <br/>
      <label for="file-upload" class="custom-file-upload" style="border: 1px solid #ccc;
    display: inline-block;
    padding: 6px 12px;
    cursor: pointer;
    border-radius: 3rem;
    color: white;
    background-color: #FFC300; 
    border: 0;  
    text-align: center; 
    width: 70%; 
    font-weight:bold;">  Seleccionar Foto
</label><input id="file-upload" type="file" style="display: none;" name="u_image" value="" required="" />
      <!-- <input type='file' class="signbutton" title="Select" id="aa" onchange="pressed()" style=" border-radius: 3rem;color:white; padding: 1rem ;background-color: #FFC300; border: 0;  text-align: center; width: 70%; font-weight:bold; color:transparent;" value="Seleccionar Foto">
      <button class="signbutton" id="upload" style="text-align: center; width: 70%; font-weight:bold">Seleccionar Foto</button></div> -->
  </div>
  <div class="form-group" style="margin:0px 20px 0px 20px; position: relative;top: 250px">
    <label for="exampleFormControlInput1">Lugar</label>
    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Dereccion del Lugar del Eventos" name="mail" value = "<?php echo $evnt[0]->description; ?>" required>
  </div>

   <div class="form-row" style="margin:0px 20px 0px 20px; position: relative;top: 300px">
    <div class="col-md-4 mb-3">
      <label for="validationCustom01">Fecha</label>
      <input type="phone" class="form-control" id="d" name="phone" placeholder="00/00/0000"  value = "<?php echo $evnt[0]->date; ?>" required >
      <div class="valid-feedback">
        Looks good!
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom02">Hora</label>
      <input type="text" class="form-control" id="h" name="u_name" placeholder="00:00" value = "<?php echo $evnt[0]->time; ?>" required >
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom02">Valor de Boleto</label>
      <input type="text" class="form-control" id="validationCustom02" name="u_password" value = "<?php echo $evnt[0]->ticket_value; ?>" placeholder="$000.00" required>
    </div>
  </div>


  <!-- <div style="float:left;margin-right:40px; position: relative;top: 240px">
    <label  class="slabels"for="add">Correo</label>

    <input class="stretched " id="add" style="width: 1060px" type="text" value="" name="add" placeholder="Tu correo electrónico">
  </div>
 -->    <!-- <div class="info-container" style="background-color: red; position: relative;top: 200px">
    <div class="prof"><label  class="slabels"for="mail">Telefono</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="Telefono"> </div>
    <div class="prof"><label  class="slabels"for="mail">Usuario</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="Usuario"> </div>
    <div class="prof"><label  class="slabels"for="mail">Contraseña</label>
    <input class="c-input-field " id="mail" style="width: 80%" type="email" value="" name="mail" placeholder="Contraseña"> </div>
  </div> -->
  
  <!-- <div style="float:left;margin-right:40px; position: relative;top: 240px">
    <label  class="slabels signbutton"for="add" style="padding: 3px;">Nota:</label>
    <br/> <p style="padding-left: 10px">Solo puede Cambiar los datos (Telefono, Contraseña y Logo)</p>
  </div> -->
  <!-- <div class="row" style=" position: relative; top: 250px;">
    <div class="col text-center">
      <button class="btn btn-default signbutton" style="border-radius: 3rem;">Centered button</button>
    </div>
  </div> --> <div class="row">
  <div style=" position: relative; top: 400px; text-align: center;"class="inner col text-center"><input type="submit" class="signbutton btn btn-default" style="text-align: center;" name="update" value="Guardar">
    <?php 
    $data= array('type'=>'submit', 'class'=>'signbutton btn btn-default', 'style'=>'text-align: center;', 'name'=>'update', 'value'=>'Guardar');
    form_submit($data); ?>
  </div> 
</div>
  <?php echo form_close(); ?>
  </div>
  </main>
<script>
  window.pressed = function(){
    var a = document.getElementById('aa');
    if(a.value == "")
    {
        fileLabel.innerHTML = "Choose file";
    }
    else
    {
        var theSplit = a.value.split('\\');
        fileLabel.innerHTML = theSplit[theSplit.length-1];
    }
};
</script>
</body>

</html>
