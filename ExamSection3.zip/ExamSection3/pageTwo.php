<?php
$fname=$lname=$mail=$p1=$p2=$add=$city=$state=$zip=$ph=$cn=$nation=$bdate=$details=$gall=$sub=$link=$bday=$fav=$int=$accept="";
$fnameErr=$lnameErr=$mailErr=$p1Err=$p2Err=$addErr=$cityErr=$stateErr=$zipErr=$phErr=$cnErr=$nationErr=$bdateErr=$detailsErr=$gallErr=$subErr=$linkErr=$bdayErr=$favErr=$intErr=$acceptErr="";

if($_SERVER["REQUEST_METHOD"] == "POST"){
  if(empty($_POST['first'])){
    $fnameErr =" required";
  }else{
    $fname .= test_input($_POST['first']);
  }
  if(empty($_POST['last'])){
    $lnameErr= "required";
  }else{
    $lname .= test_input($_POST['last']);    
  }
  if(empty($_POST['email'])){
    $mailErr=" required";
  }else{
    $mail .= test_input($_POST['email']);
  }
  if(empty($_POST['pass1'])){
    $p1Err = "required";
  }else{
    $p1 .= test_input($_POST['pass1']);
  }
  if(empty($_POST['pass2'])){
    $p2Err .= " required";
  }else{
    $p2 .= test_input($_POST['pass2']);
  }
  if(empty($_POST['address'])){
    $addErr =" required";
  }else{
    $add .= test_input($_POST['address']);
  }
  if(empty($_POST['city'])){
    $cityErr= "required";
  }else{
    $city .= test_input($_POST['city']);    
  }
  if(empty($_POST['state'])){
    $stateErr=" required";
  }else{
    $state .= test_input($_POST['state']);
  }
  if(empty($_POST['zip'])){
    $zipErr = "required";
  }else{
    $zip .= test_input($_POST['zip']);
  }
  if(empty($_POST['phone'])){
    $phErr .= " required";
  }else{
    $ph .= test_input($_POST['phone']);
  }
  if(empty($_POST['country'])){
    $cnErr =" required";
  }else{
    $cn .= test_input($_POST['country']);
  }
  if(empty($_POST['nationality'])){
    $nationErr= "required";
  }else{
    $nation .= test_input($_POST['nationality']);    
  }
  if(empty($_POST['birthdate'])){
    $bdateErr=" required";
  }else{
    $bdate .= test_input($_POST['birthdate']);
  }
  if(empty($_POST['details'])){
    $detailsErr = "required";
  }else{
    $details .= test_input($_POST['details']);
  }
  if(empty($_POST['galleryName'])){
    $gallErr .= " required";
  }else{
    $gall .= test_input($_POST['galleryName']);
  }
  if(empty($_POST['subject'])){
    $subErr=" required";
  }else{
    $sub .= test_input($_POST['subject']);
  }
  if(empty($_POST['link'])){
    $linkErr = "required";
  }else{
    $link .= test_input($_POST['link']);
  }
  if(empty($_POST['birthday'])){
    $bdayErr .= " required";
  }else{
    $bday.= test_input($_POST['birthday']);
  }
  if(empty($_POST['favorite'])){
    $favErr = "required";
  }else{
    $fav .= test_input($_POST['favorite']);
  }
  if(empty($_POST['interest'])){
    $intErr .= " required";
  }else{
    $int .= test_input($_POST['interest']);
  }
  if(empty($_POST['accept'])){
    $acceptErr .= " required";
  }else{
    $accept .= test_input($_POST['accept']);
  }
}

function test_input($data){
  $data = trim($data);
  $data = stripcslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
if(isset($_POST['cusForm'])){
  if($fnameErr=="" && $lnameErr== "" && $mailErr=="" && $p1Err=="" && $p2Err=="" && $addErr== "" && $cityErr=="" && $stateErr== "" && $zipErr== "" && $phErr=="" && $cnErr=="" && $nationErr=="" && $bdateErr=="" && $detailsErr=="" && $gallErr=="" && $subErr=="" && $linkErr== "" && $bdayErr== "" && $favErr=="" && $intErr== "" && $acceptErr=""){
    $con = mysqli_connect('localhost','root','amank','art') or die('connection failed');
   $insert_user = "insert into customers(FirstName,LastName,Address,City,Region,Country,Postal,Phone,Email,Privacy) values ('$fname','$lname','$add','$city,'$state','$cn','$zip','$ph','')";
     $run_user = mysqli_query($con, $insert_user);
  if($run_user){
    echo "<script>alert('The cusomer has been added.')</script>";
    echo "<script>window.open('pageTwo.php','_self')</script>";
  }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artist Registration 2</title>

   <link href="css/reset.css" rel="stylesheet">
   <link href="css/assign1.css" rel="stylesheet">
      <script>
        $fname=$lname=$mail=$p1=$p2=$add=$city=$state=$zip=$ph=$cn=$nation=$bdate=$details=$gall=$sub=$link=$bday=$fav=$int=$accept"";
        $fnameErr=$lnameErr=$mailErr=$p1Err=$p2Err=$addErr=$cityErr=$stateErr=$zipErr=$phErr=$cnErr=$nationErr=$bdateErr=$detailsErr=$gallErr=$subErr=$linkErr=$bdayErr=$favErr=$intErr=$acceptErr="";
     function validateForm(){
      var fname = document.forms['artform']['first'];
      var lname = document.forms['artform']['last'];
      var mail = document.forms['artform']['email'];
      var p1 = document.forms['artform']['pass1'];
      var p2 = document.forms['artform']['pass2'];
      var add= document.forms['artform']['address'];
      var city = document.forms['artform']['city'];
      var state = document.forms['artform']['state'];
      var zip = document.forms['artform']['zip'];
      var ph = document.forms['artform']['phone'];
      var cn = document.forms['artform']['country'];
      var nation = document.forms['artform']['nationality'];
      var bdate = document.forms['artform']['birthdate'];
      var details = document.forms['artform']['details'];
      var gall = document.forms['artform']['galleryName'];
      var sub = document.forms['artform']['subject'];
      var link = document.forms['artform']['link'];
      var bday = document.forms['artform']['birthday'];
      var fav = document.forms['artform']['favorite'];
      var int = document.forms['artform']['interest'];
      var accept = document.forms['artform']['accept'];

      if(fname.value==""){
        window.alert("Please enter the name");
        return false;
      }
      if(lname.value==""){
        window.alert("Please enter the lname");
        return false;
      }
      if(mail.value==""){
        window.alert("Please enter the mail");
        return false;
      }
      if(p1.value==""){
        window.alert("Please enter the password");
        return false;
      }
      if(p2.value==""){
        window.alert("required");
        return false;
      }
      if(add.value==""){
        window.alert("required");
        return false;
      }
      if(city.value==""){
        window.alert("required");
        return false;
      }
      if(state.value==""){
        window.alert("required");
        return false;
      }
      if(zip.value==""){
        window.alert("required");
        return false;
      }
      if(ph.value==""){
        window.alert("required");
        return false;
      }
       if(cn.value==""){
        window.alert("required");
        return false;
      }
       if(nation.value==""){
        window.alert("required");
        return false;
      }
       if(bdate.value==""){
        window.alert("required");
        return false;
      }
       if(details.value==""){
        window.alert("required");
        return false;
      }
       if(gall.value==""){
        window.alert("required");
        return false;
      }
       if(sub.value==""){
        window.alert("required");
        return false;
      }
       if(link.value==""){
        window.alert("required");
        return false;
      }
       if(bday.value==""){
        window.alert("required");
        return false;
      }
       if(fav.value==""){
        window.alert("required");
        return false;
      }
       if(int.value==""){
        window.alert("required");
        return false;
      }
       if(accept.value==""){
        window.alert("required");
        return false;
      }
      if(accept.value==""){
        window.alert("required");
        return false;
      }
      if(!/\S+@\S+\.\S+/.test(mail)){
        window.alert("invalid mail");
        return false;
      }
      if(!/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-.]?([0-9]{4})$/.test(ph)){
        window.alert("invalid Phone");
        return false;
      }
      if(!/\S{8,}$/.test(pass1)){
        window.alert("invalid Password");
        return false;
      }
       if(!/\S{8,}$/.test(pass2)){
        window.alert("invalid Password");
        return false;
      }
      return true;
     }
   </script>

</head>
<body>

<header>
    <div id="topHeaderRow" >
        <nav >
            <ul >
                <li><a href="pageLogin.html"> Login</a></li>
                <li><a href="#"> Wish List</a></li>
                <li><a href="#"> Shopping Cart</a></li>
                <li><a href="#"> Checkout</a></li>                  
            </ul>
        </nav>
   </div>   <!-- end topHeaderRow -->
   
   <div id="logoRow" >
        <h1>Art Store</h1> 
   </div>  <!-- end logoRow -->
   
   <div id="mainNavigationRow" >
         <nav >
             <ul >
               <li ><a href="pageOne.html">Home</a></li>
               <li><a href="#">About Us</a></li>
               <li><a href="#">Art Works</a></li>
               <li><a href="#">Artists</a></li>
             </ul>              

         </nav>
   </div>  <!-- end mainNavigationRow -->
   
</header>

<main>
   <h2>Artist Registration</h2>
   <form method="post" onsubmit="return validateForm()" action="validateform.php://www.randyconnolly.com/tests/process.php">
   
      <h3>1. User Info</h3>
      <table class="userform">
         <tr>
            <td><label>First Name</label><br><input type="text" name="first" size="20" required ></td>
            <td><label>Last Name</label><br><input type="text" name="last" size="22" required></td>
         </tr>
         <tr>
            <td colspan="3">
               <label>Email</label><br><input type="email" name="email" size="60" required>
            </td>
         </tr>
         <tr>
            <td><label>Password</label><br><input type="password" name="pass1" size="20" required></td>
            <td><label>Password Repeat</label><br><input type="password" name="pass2" size="20" required></td>
         </tr>         
      </table>
      
      <h3>2. Location</h3>
      <table class="userform">
         <tr>
            <td colspan="3">
               <label>Address</label><br><input type="text" name="address" size="60" required>
            </td>
         </tr>
         <tr>
            <td><label>City</label><br><input type="text" name="city" size="20"required></td>
            <td><label>State</label><br><input type="text" name="state" size="4" required></td>
            <td><label>Zip</label><br><input type="text" name="zip" size="10" required></td>
         </tr>   
         <tr>
            <td>
               <label>Phone</label><br><input type="tel" name="phone" size="20" required >
            </td>
            <td colspan="2">
               <label>Country</label><br>
               <select name="country" required>
                  <option>Canada</option>
                  <option>Denmark</option>
                  <option>France</option>
                  <option>United States</option>
               </select>
            </td>
         </tr>
         <tr>
            <td>
               <label>Continent</label><br>
               <input type="radio" name="continent" value="1" required>North America<br>
               <input type="radio" name="continent" value="2">Europe<br>
               <input type="radio" name="continent" value="3">South America<br>
            </td>
         </tr>
      </table>    

      <h3>3. Personal Details</h3>
      <table class="userform">
         <tr>
          <td><label>Nationality</label><br><input type="text" name="nationality" size="20" required></td>
           
            <td><label>Death Date</label><br><input type="date" name="birthdate" required></td>
            <td><label>Details</label><br><textarea required rows="10" cols=30" name="details" >Be always Nice</textarea></td>
         </tr>
		 <tr>
			<td><label>Gallery Name</label><br><input type="text" name="galleryName" size="20" required></td>
			<td colspan="2">
               <label>Subject Interested</label><br>
               <select name="subject" required>
				  <option>-None-</option>
                  <option>Animals </option>
                  <option>Scenic</option>
                  <option>Music</option>
                  <option>Sports</option>
				  <option>Abstract</option>
				  <option>Transportation</option>
				  <option>Architecture</option>
				  <option>Still Life</option>
				  <option>People</option>
				  <option>Botanical</option>
				  <option>Cuisine</option>
				  <option>History</option>
				  <option>Performing Arts</option>
				  <option>Allegory</option>
				  <option>Mythological</option>
               </select>
            </td>
		 </tr>
         <tr>
            <td colspan="3">
               <label>Link</label><br><input type="url" name="link"  required>Love it!
            </td>
         </tr>
		 <tr>
            <td><label>Birth Day</label><br><input type="date" name="birthday" size="20" required></td>
            <td><label>Favorite Color</label><br><input type="color" name="favorite" size="20"></td>
         </tr>
         <tr>
            <td colspan="3">
               <label>Interest In Art</label><br>Minimal<input type="range" name="interest" min="0" max="10" step="1" required>Love it!
            </td>
         </tr>
		 </table>
		 
     <h3>4. All Done</h3>
      <table class="userform">
         <tr>
            <td colspan="3">
               <input type="checkbox" name="accept" required>
               <label>I agree to the <a href="#">Terms of the Site</a></label>               
            </td>
         </tr>
         <tr>
            <td colspan="3">
               <button type="submit" name="cusForm" class="fancyBtn">
                  <img src="images/button_ok.png"> Sign me up!
               </button>
            </td>
         </tr>       
      </table>      
   </form>
</main>
<footer>
       <p>All images are copyright to their owners. This is just a hypothetical site
       <span >&copy; 2019 Copyright Art Store</span></p>
</footer>


  </body>
</html>
